﻿using Blazored.LocalStorage;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Infraestructure.Data;
using PortalProcrea.Web.Models;
using Web.Services.CartService;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyInjection
{
    public static IServiceCollection AddWebServices(this IServiceCollection services)
    {
        services.AddDatabaseDeveloperPageExceptionFilter();
        services.AddHttpContextAccessor();

        services.AddScoped<IUser, CurrentUser>();
        services.AddBlazoredLocalStorage();

        services.AddScoped<ICartService, CartService>();
      

        services.AddHealthChecks()
            .AddDbContextCheck<ApplicationDbContext>();

       // services.AddExceptionHandler<CustomExceptionHandler>();

        return services;
    }

}
