﻿using Domain.Entities.Nomenclators;
using Microsoft.AspNetCore.Identity;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Infraestructure.Identity;
using System.Security.Claims;

namespace PortalProcrea.Web.Models;
public class CurrentUser : IUser
{
    private readonly IHttpContextAccessor _httpContextAccessor;
  

    public CurrentUser(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
        
    }

    public string? Id => _httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);

    public Provider? Provider
    {
        get
        {

            var userId = Id;
            if (userId != null)
            {
                return _httpContextAccessor.HttpContext?.RequestServices.GetRequiredService<IIdentityService>()
                .GetProviderByUserId(userId);
            }
            return null;
        }
    }
}

