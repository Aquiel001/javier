﻿using System.ComponentModel.DataAnnotations;

namespace PortalProcrea.Web.Models;

public class LoginModel
{
    [Required]
    public string? UserName { get; set; }
    [Required]
    [MinLength(6)]
    public string? Password { get; set; }
}
