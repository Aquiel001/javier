﻿using Application.ShoppingCart.Dtos;
using Blazorise;

namespace Web.Services.CartService
{
    public interface ICartService
    {
        event Action OnChange;
        Task AddToCart(ShoppingCartItemDto item);
        Task<List<ShoppingCartItemDto>> GetCartItems();
        Task DeleteItem(ShoppingCartItemDto item);
        Task EmptyCart();
        Task<int> GetCartItemsCountAsync();
    }
}
