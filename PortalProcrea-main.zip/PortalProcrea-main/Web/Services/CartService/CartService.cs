﻿using Application.ShoppingCart.Commands.AddItemsToShoppingCart;
using Application.ShoppingCart.Commands.RemoveElementsFromShoppingCart;
using Application.ShoppingCart.Commands.RemoveItemsFromShoppingCart;
using Application.ShoppingCart.Dtos;
using Application.ShoppingCart.Queries.GetShoppingCartByCustomer;
using Blazored.LocalStorage;
using Blazorise;
using MediatR;
using NuGet.Protocol.Plugins;
using PortalProcrea.Application.Common.Interfaces;
using ISender = MediatR.ISender;

namespace Web.Services.CartService
{
    public class CartService : ICartService
    {
        private readonly ILocalStorageService _localStorage;
        private readonly IToastService _toastService;
        private readonly ISender _sender;
        private readonly IUser _user;
       

        public event Action OnChange;

        public CartService(
            ILocalStorageService localStorage,
            IToastService toastService,
            ISender sender,
            IUser user)
        {
            _localStorage = localStorage;
            _toastService = toastService;
            _sender = sender;
            _user = user;
        }

        public async Task AddToCart(ShoppingCartItemDto item)
        {
            if (string.IsNullOrEmpty(_user.Id))
            {
                var cart = await _localStorage.GetItemAsync<List<ShoppingCartItemDto>>("cart");
                if (cart == null)
                {
                    cart = new List<ShoppingCartItemDto>();
                }

                var sameItem = cart
                    .Find(x => x.ProductId == item.ProductId);
                if (sameItem == null)
                {
                    cart.Add(item);
                }
                else
                {
                    sameItem.Quantity += item.Quantity;
                }

                await _localStorage.SetItemAsync("cart", cart);
            }
            else 
            {
                await _sender.Send(new AddItemToShoppingCartCommand 
                {
                    Item = item
                });
            }
           
            await _toastService.Success(item.ProductName, "Added to cart:");
            OnChange.Invoke();
        }

        public async Task<List<ShoppingCartItemDto>> GetCartItems()
        {
            var cart = new List<ShoppingCartItemDto>();

            if (string.IsNullOrEmpty(_user.Id))
            {
                cart = await _localStorage.GetItemAsync<List<ShoppingCartItemDto>>("cart");
                if (cart is null)
                {
                    return new List<ShoppingCartItemDto>();
                }
                
            }
            else 
            {
               var result = await _sender.Send(new GetShoppingCartByCustomerQuery());
               if (result is not null) 
               {
                    cart = result.Items.ToList();
               }
            }

            return cart;
        }

        public async Task DeleteItem(ShoppingCartItemDto item)
        {

            if (string.IsNullOrEmpty(_user.Id))
            {
                var cart = await _localStorage.GetItemAsync<List<ShoppingCartItemDto>>("cart");
                if (cart == null)
                {
                    return;
                }

                var cartItem = cart.Find(x => x.ProductId == item.ProductId);
                cart.Remove(cartItem);

                await _localStorage.SetItemAsync("cart", cart);
            }
            else 
            {
               await _sender.Send(new RemoveItemsFromShoppingCartCommand 
               {
                     ItemIds = new List<int>() { item.Id }
               });
            }
            
            OnChange.Invoke();
        }

        public async Task EmptyCart()
        {
            if (string.IsNullOrEmpty(_user.Id))
            {
                await _localStorage.RemoveItemAsync("cart");
               
            }
            else 
            {
                await _sender.Send(new CleanShoppingCartCommand
                {
                    UserId = _user.Id
                });
            }

            OnChange.Invoke();
        }

        public async Task<int> GetCartItemsCountAsync()
        {
            var cart = await GetCartItems();
            return cart.Count;

        }
    }
}
