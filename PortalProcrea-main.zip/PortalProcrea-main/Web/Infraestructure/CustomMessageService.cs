﻿using Blazorise;
using Microsoft.AspNetCore.Components;

namespace Web.Infraestructure
{
    public class CustomMessageService : IMessageService
    {
        public event EventHandler<MessageEventArgs> MessageReceived;

        public async Task<bool> Confirm(string message, string? title = null, Action<MessageOptions> options = null)
        {
            Action<MessageOptions> customOptions = options =>
            {
                options.ConfirmButtonClass="text-dark bg-warning"; // Cambiar la duración del mensaje a 5 segundos
            };

            // Llamar a la acción personalizada con las modificaciones
            customOptions.Invoke(new MessageOptions());

            return await this.Confirm(message, title, customOptions);
        }

        public Task<bool> Confirm(MarkupString message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Error(string message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Error(MarkupString message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }


        public Task Info(string message, string title = null, Action<MessageOptions> options = null)
        {
            Action<MessageOptions> customOptions = options =>
            {
                options.ConfirmButtonClass = "text-dark bg-warning"; // Cambiar la duración del mensaje a 5 segundos
            };

            // Llamar a la acción personalizada con las modificaciones
            customOptions.Invoke(new MessageOptions());

            return this.Info(message, title, customOptions);
        }

        public Task Info(MarkupString message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Success(string message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Success(MarkupString message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Warning(string message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        public Task Warning(MarkupString message, string title = null, Action<MessageOptions> options = null)
        {
            throw new NotImplementedException();
        }

        // Personalizar otros tipos de mensajes...
    }
}
