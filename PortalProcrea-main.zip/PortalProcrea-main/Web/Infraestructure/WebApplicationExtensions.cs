﻿namespace PortalProcrea.Web.Infraestructure;

public static class WebApplicationExtensions
{
}
