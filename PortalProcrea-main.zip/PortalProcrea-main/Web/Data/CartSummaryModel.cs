﻿namespace Web.Data
{
    public class CartSummaryModel
    {
        public string Vendor { get; set; } = string.Empty;
        public int Quantity { get; set; }
    }
}
