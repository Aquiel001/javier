﻿using Domain.Entities.Nomenclators;
using Domain.Interfaces;
using Microsoft.AspNetCore.Identity;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortalProcrea.Infraestructure.Identity;

public class ApplicationUser : IdentityUser, IProvider
{
    public string Name { get; set; } = default!;
    public string LastName { get; set; } = default!;

   // [ForeignKey("ProviderId")]
   // public virtual int ProviderId { get; set; }
    public virtual Provider? Provider { get; set; }
}
