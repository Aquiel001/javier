﻿using Application.Common.Security;
using Application.Nomenclators.Providers.Queries;
using AutoMapper;
using Domain.Entities.Nomenclators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PortalProcrea.Infraestructure.Identity;

    public class ApplicationUserDto : UserDto
    {
        private class Mapping : Profile
        {
            public Mapping()
            {
              CreateMap<ApplicationUser, UserDto>();
            }
        }
    }

