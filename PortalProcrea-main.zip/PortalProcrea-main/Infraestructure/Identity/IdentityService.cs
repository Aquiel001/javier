﻿using Application.Common.Security;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using Domain.Entities.Nomenclators;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using PortalProcrea.Common.Interfaces;
using System.Collections;

namespace PortalProcrea.Infraestructure.Identity;

public class IdentityService : IIdentityService
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly IUserClaimsPrincipalFactory<ApplicationUser> _userClaimsPrincipalFactory;
    private readonly IAuthorizationService _authorizationService;
    private readonly IApplicationDbContext _applicationDbContext;
    private readonly IMapper _mapper;
  
    public IdentityService(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        IUserClaimsPrincipalFactory<ApplicationUser> userClaimsPrincipalFactory,
        IAuthorizationService authorizationService,
        IApplicationDbContext applicationDbContext,
        IMapper mapper
        )
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _userClaimsPrincipalFactory = userClaimsPrincipalFactory;
        _authorizationService = authorizationService;
        _applicationDbContext = applicationDbContext;
        _mapper = mapper;
    }



    public async Task<string?> GetUserNameAsync(string userId)
    {
        var user = await _userManager.Users.FirstAsync(u => u.Id == userId);

        return user.UserName;
    }

    public async Task<UserDto?> GetUserByIdAsync(string userId)
    {
        var user = await _userManager.Users.FirstAsync(u => u.Id == userId);

        return _mapper.Map<UserDto>(user);
    }

    public async Task<UserDto?> GetUserByUserNameAsync(string userName)
    {
        var user = await _userManager.Users.FirstAsync(u => u.UserName == userName);

        return _mapper.Map<UserDto>(user);
    }

    public UserDto? GetUserById(string userId)
    {
        var user = _userManager.Users.First(u => u.Id == userId);

        return _mapper.Map<UserDto>(user);
    }

    public Provider? GetProviderByUserId(string userId)
    {
        var user = _userManager.Users.Include(x => x.Provider).First(u => u.Id == userId);

        return user.Provider;
    }

    public async Task<(Result Result, string UserId)> CreateUserAsync(RegisterDto registerDto)
    {
        var user = new ApplicationUser
        {
            UserName = registerDto.UserName,
            Email = registerDto.Email,
            Name = registerDto.Name,
            LastName = registerDto.LastName,
            PhoneNumber = registerDto.PhoneNumber
        };

        if (registerDto.ProviderId > 0)
        {
            var provider = await _applicationDbContext.Providers.FindAsync(registerDto.ProviderId);

            if (provider is not null)
            {
                user.Provider = provider;
            }
        }

        var result = await _userManager.CreateAsync(user, registerDto.Password);

        return (result.ToApplicationResult(), user.Id);
    }

    public async Task<(Result Result, string UserId)> AddRolesAsync(string userId, string[] roles)
    {
        var user = await _userManager.Users.FirstAsync(u => u.Id == userId);
        var result = await _userManager.AddToRolesAsync(user, roles);

        return (result.ToApplicationResult(), user.Id);
    }

    public async Task<(Result Result, string UserId)> RemoveRolesAsync(string userId, string[] roles)
    {
        var user = await _userManager.Users.FirstAsync(u => u.Id == userId);
        var result = await _userManager.RemoveFromRolesAsync(user, roles);

        return (result.ToApplicationResult(), user.Id);
    }

    public async Task<bool> IsInRoleAsync(string userId, string role)
    {
        var user = _userManager.Users.SingleOrDefault(u => u.Id == userId);

        return user != null && await _userManager.IsInRoleAsync(user, role);
    }

    public async Task<bool> AuthorizeAsync(string userId, string policyName)
    {
        var user = _userManager.Users.SingleOrDefault(u => u.Id == userId);

        if (user == null)
        {
            return false;
        }

        var principal = await _userClaimsPrincipalFactory.CreateAsync(user);

        var result = await _authorizationService.AuthorizeAsync(principal, policyName);

        return result.Succeeded;
    }

    public async Task<Result> DeleteUserAsync(string userId)
    {
        var user = _userManager.Users.SingleOrDefault(u => u.Id == userId);

        return user != null ? await DeleteUserAsync(user) : Result.Success();
    }

    public async Task<Result> DeleteUserAsync(ApplicationUser user)
    {
        var result = await _userManager.DeleteAsync(user);

        return result.ToApplicationResult();
    }

    public async Task<bool> CheckUserAndPassword(string username, string password)
    {

        var user = await _userManager.FindByEmailAsync(username);
        if (user is null)
            return false;

        var result = await _signInManager.CheckPasswordSignInAsync(user, password, lockoutOnFailure: false);

        if (result.Succeeded)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public async Task<PaginatedList<UserDto>> GetUsersWithPagination(int pageNumber = 1, int pageSize = 10)
    {
        return await _userManager.Users
              .OrderByDescending(x => x.Id)
              .ProjectTo<UserDto>(_mapper.ConfigurationProvider)
              .PaginatedListAsync(pageNumber, pageSize);
    }

    public async Task<IEnumerable<UserDto>> GetUsersByProviderAsync(int providerId)
    {
        return await _userManager.Users
              .Where(x => x.Provider != null &&  x.Provider.Id == providerId)
              .ProjectTo<UserDto>(_mapper.ConfigurationProvider)
              .ToListAsync();
    }

    public async Task<IEnumerable<UserDto>> GetUsersByIdsAsync(IEnumerable<string> userIds)
    {
        return await _userManager.Users
              .Where(x => userIds.Contains(x.Id))
              .ProjectTo<UserDto>(_mapper.ConfigurationProvider)
              .ToListAsync();
    }
}
