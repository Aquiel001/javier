﻿using Domain.Entities.Nomenclators;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infraestructure.Data.Configurations.Nomenclators
{
    public class CurrencyConfiguration : IEntityTypeConfiguration<Currency>
    {
        public void Configure(EntityTypeBuilder<Currency> builder)
        {
            builder.Property(t => t.Name)
               .HasMaxLength(250)
               .IsRequired();

            builder.Property(t => t.CurrencyCode)
               .HasMaxLength(50)
               .IsRequired();

            builder.Property(p => p.Rate)
           .HasColumnType("decimal(18,2)")
           .HasPrecision(18, 2);

            //additioning default menus to data base
            builder.HasData(new List<Currency>
            {
                new Currency
                {
                    Id= 1,
                    Name = "Pesos Cubanos",
                    CurrencyCode = "CUP",
                    Rate = 300,
                    Active= true
                },
                new Currency
                {
                    Id= 2,
                    Name = "Moneda Libremente Convertible",
                    CurrencyCode = "MLC",
                    Rate = 250,
                    Active= true
                },
                new Currency
                {
                    Id= 3,
                    Name = "Dolar",
                    CurrencyCode = "USD",
                    Rate = 1,
                    Active= true
                },
                new Currency
                {
                    Id= 4,
                    Name = "Euro",
                    CurrencyCode = "EUR",
                    Rate = 0.75,
                    Active= true
                }
            });
        }
    }
}
