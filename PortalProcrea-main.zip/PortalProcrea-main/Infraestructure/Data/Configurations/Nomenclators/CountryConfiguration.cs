﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Entities.Nomenclators;

namespace Infraestructure.Data.Configurations.Nomenclators
{
    public class CountryConfiguration : IEntityTypeConfiguration<Country>
    {
        public void Configure(EntityTypeBuilder<Country> builder)
        {
            builder.Property(t => t.Name)
               .HasMaxLength(250)
               .IsRequired();

            builder.Property(t => t.ShortName)
               .HasMaxLength(50)
               .IsRequired();

            //additioning default menus to data base
            builder.HasData(new List<Country>
            {
                new Country
                {
                    Id= 1,
                    Name = "Cuba",
                    ShortName = "Cuba",
                    Active= true
                },
                new Country
                {
                    Id= 2,
                    Name = "Estados Unidos",
                    ShortName = "USA",
                    Active= true
                },
                new Country
                {
                    Id= 3,
                    Name = "España",
                    ShortName = "Esp",
                    Active= true
                }
            });
        } 
    }
}
