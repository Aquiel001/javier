﻿using Domain.Entities.Messages;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Constants;

namespace Infraestructure.Data.Configurations.Messages
{
    public class EmailAccountConfiguration : IEntityTypeConfiguration<EmailAccount>
    {
        public void Configure(EntityTypeBuilder<EmailAccount> builder)
        {
            builder.Property(t => t.DisplayName)
               .HasMaxLength(255);

            builder.Property(t => t.Email)
             .HasMaxLength(255)
             .IsRequired();

            builder.Property(t => t.Host)
           .HasMaxLength(255)
           .IsRequired();

            builder.Property(t => t.Username)
           .HasMaxLength(255)
           .IsRequired();

            builder.Property(t => t.Password)
           .HasMaxLength(255)
           .IsRequired();

            //additioning  data
            builder.HasData(new List<EmailAccount>
            {
               new EmailAccount
               {
                    Id = 1,
                    Email = "adurandbazan@gmail.com",
                    DisplayName = "Portal Procrea",
                    Host = "smtp.gmail.com",
                    Port = 465,
                    Username = "adurandbazan@gmail.com",
                    Password = "xneq xznu lpvr jwyu",
                    EnableSsl = true,
                    UseDefaultCredentials = false
               }
            });

        }
    }
}
