﻿using Application.Common.Interfaces;
using Infraestructure.Common.Factories;
using Infraestructure.Data.Interceptors;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;
using PortalProcrea.Infraestructure.Data;
using PortalProcrea.Infraestructure.Data.Interceptors;
using PortalProcrea.Infraestructure.Identity;
using System.Reflection;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("DefaultConnection");

        services.AddAutoMapper(Assembly.GetExecutingAssembly());
        services.AddScoped<ISaveChangesInterceptor, EntityWithProviderInterceptor>();
        services.AddScoped<ISaveChangesInterceptor, AuditableEntityInterceptor>();
        services.AddScoped<ISaveChangesInterceptor, DispatchDomainEventsInterceptor>();
       
        services.AddDbContext<ApplicationDbContext>((sp, options) =>
        {
            options.AddInterceptors(sp.GetServices<ISaveChangesInterceptor>());
            options.UseSqlServer(connectionString);
            options.UseLazyLoadingProxies();
        });

        services.AddScoped<IApplicationDbContext>(provider => provider.GetRequiredService<ApplicationDbContext>());
        services.AddScoped<IApplicationDbContextFactory, ApplicationDbContextFactory>();


        services.AddScoped<ApplicationDbContextInitialiser>();

        services
          .AddDefaultIdentity<ApplicationUser>()
          .AddRoles<IdentityRole>()
          .AddEntityFrameworkStores<ApplicationDbContext>();

     
        services.AddTransient<IIdentityService, IdentityService>();
        services.AddScoped<AuthenticationStateProvider, ServerAuthenticationStateProvider>();

        services.AddAuthorization(options =>
            options.AddPolicy(Policies.CanPurge, policy => policy.RequireRole(Roles.Administrator)));

        return services;
    }
}