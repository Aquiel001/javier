﻿using Microsoft.EntityFrameworkCore.Design;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Infraestructure.Data;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using PortalProcrea.Application.Common.Interfaces;
using Application.Common.Interfaces;

namespace Infraestructure.Common.Factories
{
    public class ApplicationDbContextFactory : IDesignTimeDbContextFactory<ApplicationDbContext>, IApplicationDbContextFactory
    {
        private readonly IConfiguration _configuration;
        private readonly IServiceProvider _serviceProvider;

        public ApplicationDbContextFactory(IConfiguration configuration, IServiceProvider serviceProvider)
        {
            _configuration = configuration;
            _serviceProvider = serviceProvider;
        }

        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseSqlServer(_configuration.GetConnectionString("DefaultConnection"));
            optionsBuilder.AddInterceptors(_serviceProvider.GetServices<ISaveChangesInterceptor>());
            optionsBuilder.UseLazyLoadingProxies();

            return new ApplicationDbContext(optionsBuilder.Options);
        }

        public IApplicationDbContext CreateDbContext()
        {
            var dbContext = CreateDbContext(new string[0]);
            return dbContext;
        }
    }

}
