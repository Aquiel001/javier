﻿using Domain.Entities.Offers;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Offers.Events
{
    public class RejectedOffersEvent : BaseEvent
    {
        public RejectedOffersEvent(IList<Offer> offers) 
        {
            Offers = offers;
        }

        public IList<Offer> Offers { get; set; }
    }
}
