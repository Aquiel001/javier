﻿using Application.Offers.Dtos;
using AutoMapper;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Offers.Queries
{
    public class GetOfferByIdQuery : IRequest<OfferDto>
    {
        public int Id { get; set; }
    }

    public class GetOfferByIdQueryHandler : IRequestHandler<GetOfferByIdQuery, OfferDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetOfferByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<OfferDto> Handle(GetOfferByIdQuery request, CancellationToken cancellationToken)
        {
            var offer = await _context.Offers.FindAsync(request.Id);

            return _mapper.Map<OfferDto>(offer);
        }
    }
}
