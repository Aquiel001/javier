﻿using Application.Offers.Dtos;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Offers.Queries
{
    public class GetOffersNotAcceptedWithPaginationQuery : IRequest<PaginatedList<OfferDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetOffersNotAcceptedWithPaginationQueryHandler : IRequestHandler<GetOffersNotAcceptedWithPaginationQuery, PaginatedList<OfferDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetOffersNotAcceptedWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<OfferDto>> Handle(GetOffersNotAcceptedWithPaginationQuery request, CancellationToken cancellationToken)
        {
            return await _context.Offers
                .Where(l => l.Accepted == null)
                .OrderByDescending(x => x.Id)
                .ProjectTo<OfferDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
