﻿using Application.Offers.Dtos;
using Application.Requests.Queries;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Offers.Queries
{
    public class GetOffersWithPaginationQuery : IRequest<PaginatedList<OfferDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetOffersWithPaginationQueryHandler : IRequestHandler<GetOffersWithPaginationQuery, PaginatedList<OfferDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetOffersWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<OfferDto>> Handle(GetOffersWithPaginationQuery request, CancellationToken cancellationToken)
        {
            return await _context.Offers
                .OrderByDescending(x => x.Id)
                .ProjectTo<OfferDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
