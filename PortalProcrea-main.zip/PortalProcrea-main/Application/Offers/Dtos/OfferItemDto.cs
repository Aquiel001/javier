﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Offers.Dtos
{
    public class OfferItemDto
    {
        public int? ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public int? ProductProviderId { get; set; }

        public int? ServiceId { get; set; }
        public string ServiceName { get; set; } = string.Empty;
        public int? ServiceProviderId { get; set; }

        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public string ImagePath { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;

    }
}
