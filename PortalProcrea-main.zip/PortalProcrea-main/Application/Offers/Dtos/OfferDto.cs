﻿using AutoMapper;
using Domain.Entities.Nomenclators;
using Domain.Entities.Offers;

namespace Application.Offers.Dtos
{
    public class OfferDto
    {
        public int Id { get; set; }
        public int OrderRequestId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerLastName { get; set; } = string.Empty;
        public bool? Accepted { get; set; }
        public DateTimeOffset Created { get; set; }
        public string? CreatedBy { get; set; }
        public List<OfferItemDto> Items { get; set; } = new();
        public decimal? TotalPrice { get; set; }

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Offer, OfferDto>()
                    .ForMember(dst => dst.CustomerName, src => src.MapFrom(a => a.OrderRequest.Customer.Name))
                    .ForMember(dst => dst.CustomerLastName, src => src.MapFrom(a => a.OrderRequest.Customer.LastName))
                    .ForMember(dst => dst.TotalPrice, src => src.MapFrom(a => a.Items.Sum(x => x.TotalPrice)));
                CreateMap<OfferItem, OfferItemDto>()
                    .ForMember(dst => dst.ProductName, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.Name : ""))
                    .ForMember(dst => dst.ProductProviderId, src => src.MapFrom(a => a.Product!.Provider!.Id))
                    .ForMember(dst => dst.ServiceName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Name : ""))
                    .ForMember(dst => dst.ServiceProviderId, src => src.MapFrom(a => a.Service!.Provider!.Id));
                
            }
        }
    }
}
