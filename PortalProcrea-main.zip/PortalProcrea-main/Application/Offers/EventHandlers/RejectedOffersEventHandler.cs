﻿using Application.Common.Interfaces;
using Application.Common.Security;
using Application.MessageTemplates.Queries;
using Application.Offers.Events;
using Domain.Constants;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Offers.EventHandlers
{
    public class RejectedOffersEventHandler : INotificationHandler<RejectedOffersEvent>
    {
        private readonly ILogger<RejectedOffersEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public RejectedOffersEventHandler(ILogger<RejectedOffersEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(RejectedOffersEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails to all marketing users which offers was rejected.");

            //var template = await _mediator.Send(new GetMessageTemplateByNameQuery
            //{
            //    Name = MessageTemplateSystemNames.RejectOfferMessage
            //});

          
            List<string> userIds = notification.Offers.Select(x => x.CreatedBy).ToList()!;
            var users = await _identityService.GetUsersByIdsAsync(userIds);


            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();

            foreach (var user in users)
            {
                _queue.Enqueue(new EmailMessage
                {
                    EmailAccount = eamailAccount,
                    FromAddress = eamailAccount.Username,
                    FromName = eamailAccount.DisplayName,
                    ToAddress = user!.Email,
                    ToName = user.Name,
                    Subject = "Reject Offer",
                   // Subject = template!.Subject,
                    Body = "Your offer was rejected",
                   // Body = template.Body,

                });
            }

            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}
