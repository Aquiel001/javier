﻿using Application.Common.Interfaces;
using Application.Offers.Dtos;
using Domain.Entities.Offers;
using Domain.Events;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Offers.Commands.CreateOffer
{
    public class CreateOfferCommand : IRequest<int>
    {
        public int OrderRequestId { get; set; }
        public List<OfferItemDto> Items { get; set; } = new();
    }

    public class CreateOfferCommandHandler : IRequestHandler<CreateOfferCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;

        public CreateOfferCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _contextFactory = contextFactory;
        }

        public async Task<int> Handle(CreateOfferCommand request, CancellationToken cancellationToken)
        {
            var offer = new Offer
            {
                OrderRequestId = request.OrderRequestId,
                Items = request.Items.Select(item => new OfferItem
                {
                    ProductId = item.ProductId,
                    ServiceId = item.ServiceId,
                    Quantity = item.Quantity,
                    UnitPrice = item.UnitPrice,
                    TotalPrice = item.TotalPrice
                }).ToList()
            };

            using (var context = _contextFactory.CreateDbContext())
            {
                context.Offers.Add(offer);
                await context.SaveChangesAsync(cancellationToken);
            };
            offer.AddDomainEvent(new CreatedOfferEvent(offer));

            return offer.Id;
        }
    }
}
