﻿using Application.Common.Interfaces;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Services.Commands.UpdateService
{
    public record UpdateServiceCommand : IRequest<int>
    {
        public int Id { get; set; }
        public string? Name { get; init; }
        public string? Code { get; init; }
        public bool New { get; set; }
        public bool ShowInMainView { get; set; }
        public bool Published { get; set; }
        public double Rating { get; set; }
        public bool Active { get; set; }
        public string? ImagePath { get; init; }
    }

    public class UpdateServiceCommandHandler : IRequestHandler<UpdateServiceCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;

        public UpdateServiceCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _contextFactory = contextFactory;
        }

        public async Task<int> Handle(UpdateServiceCommand request, CancellationToken cancellationToken)
        {
            var service = await _context.Services.FirstOrDefaultAsync(x => x.Id == request.Id);

            if (service != null)
            {
                var entity = new Service
                {
                    Id = request.Id,
                    Name = request.Name!,
                    Code = request.Code!,
                    New = request.New,
                    ShowInMainView = request.ShowInMainView,
                    Published = request.Published,
                    Rating = request.Rating,
                    Active = request.Active,
                    ImagePath = request.ImagePath!
                };

                using (var context = _contextFactory.CreateDbContext())
                {
                    context.Services.Update(entity);
                    await context.SaveChangesAsync(cancellationToken);
                }

                return service.Id;
            }
            return 0;
        }
    }
}
