﻿using Application.Common.Interfaces;
using Domain.Entities.Nomenclators;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Services.Commands.CreateService;

public record CreateServiceCommand : IRequest<int>
{
    public string? Name { get; init; }
    public string? Code { get; init; }
    public bool New { get; set; }
    public bool ShowInMainView { get; set; }
    public bool Published { get; set; }
    public double Rating { get; set; } = 0;
    public bool Active { get; set; }
    public string? ImagePath { get; init; }
}

public class CreateServiceCommandHandler : IRequestHandler<CreateServiceCommand, int>
{
    private readonly IApplicationDbContext _context;
    private readonly IApplicationDbContextFactory _contextFactory;

    public CreateServiceCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
    {
        _context = context;
        _contextFactory = contextFactory;
    }

    public async Task<int> Handle(CreateServiceCommand request, CancellationToken cancellationToken)
    {
        var entity = new Service
        {
            Name = request.Name!,
            Code = request.Code!,
            New = request.New,
            ShowInMainView = request.ShowInMainView,
            Published = request.Published,
            Rating = request.Rating,
            Active = true,
            ImagePath = request.ImagePath!
        };

        using (var context = _contextFactory.CreateDbContext())
        {
            context.Services.Add(entity);
            await context.SaveChangesAsync(cancellationToken);
        }

        return entity.Id;
    }
}
