﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Services.Commands.DeleteService
{
    public record DeleteServiceCommand : IRequest<bool>
    {
        public int Id { get; set; }
    }

    public class DeleteServiceCommandHandler : IRequestHandler<DeleteServiceCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteServiceCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteServiceCommand request, CancellationToken cancellationToken)
        {
            var product = await _context.Services.SingleOrDefaultAsync(x => x.Id == request.Id);

            if (product != null)
            {

                _context.Services.Remove(product);

                return await _context.SaveChangesAsync(cancellationToken) == 1;
            }
            return false;
        }
    }
}
