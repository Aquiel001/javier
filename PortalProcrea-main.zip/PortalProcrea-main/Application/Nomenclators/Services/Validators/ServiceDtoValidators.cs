﻿using Domain.Entities.Nomenclators;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Nomenclators.Services.Dto;

namespace Application.Nomenclators.Services.Validators
{
    public class ServiceDtoValidators : AbstractValidator<ServiceDto>
    {
        private readonly IApplicationDbContext _context;
        public ServiceDtoValidators(IApplicationDbContext context)
        {
            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(50)
                .Must(IsNameUnique)
                .WithMessage("El servicio ya existe");

            RuleFor(vm => vm.Code)
                .NotEmpty()
                .MaximumLength(30);

            _context = context;
        }
        public bool IsNameUnique(ServiceDto servicedto, string newValue)
        {
            Service service = _context.Services.FirstOrDefault(l => l.Name.Equals(newValue));
            return service == null;
        }
    }
}
