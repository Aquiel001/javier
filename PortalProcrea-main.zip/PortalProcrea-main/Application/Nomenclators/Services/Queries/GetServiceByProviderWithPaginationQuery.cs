﻿using Application.Common.Interfaces;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using PortalProcrea.Application.Nomenclators.Services.Dto;

namespace Application.Nomenclators.Services.Queries
{
    public class GetServiceByProviderWithPaginationQuery : IRequest<PaginatedList<ServiceDto>>
    {
        public int ProviderId { get; init; }
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetServiceByProviderWithPaginationQueryHandler : IRequestHandler<GetServiceByProviderWithPaginationQuery, PaginatedList<ServiceDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetServiceByProviderWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<ServiceDto>> Handle(GetServiceByProviderWithPaginationQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Services.Where(x => x.Provider != null && x.Provider.Id == request.ProviderId)
                .Include(x => x.Provider)
                .OrderByDescending(x => x.Id)
                .ProjectTo<ServiceDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
            }
        }
    }
}
