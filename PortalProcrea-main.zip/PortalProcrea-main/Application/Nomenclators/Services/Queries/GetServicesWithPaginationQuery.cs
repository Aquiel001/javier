﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using PortalProcrea.Application.Nomenclators.Services.Dto;

namespace PortalProcrea.Application.Nomenclators.Services.Queries;

public class GetServicesWithPaginationQuery : IRequest<PaginatedList<ServiceDto>>
{
    public int PageNumber { get; init; } = 1;
    public int PageSize { get; init; } = 10;
}

public class GetServicesWithPaginationQueryHandler : IRequestHandler<GetServicesWithPaginationQuery, PaginatedList<ServiceDto>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;

    public GetServicesWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<PaginatedList<ServiceDto>> Handle(GetServicesWithPaginationQuery request, CancellationToken cancellationToken)
    {
        return await _context.Services
            .OrderByDescending(x => x.Id)
            .ProjectTo<ServiceDto>(_mapper.ConfigurationProvider)
            .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
