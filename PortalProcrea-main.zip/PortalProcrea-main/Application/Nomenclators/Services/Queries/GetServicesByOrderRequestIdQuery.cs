﻿using Application.Common.Interfaces;
using AutoMapper;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Services.Queries
{
    public class GetServicesByOrderRequestIdQuery : IRequest<IEnumerable<Service>>
    {
        public int OrderRequestId {  get; set; }
        public int ProviderId { get; init; }

    }

    public class GetServicesByOrderRequestIdQueryHandler : IRequestHandler<GetServicesByOrderRequestIdQuery, IEnumerable<Service>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetServicesByOrderRequestIdQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<IEnumerable<Service>> Handle(GetServicesByOrderRequestIdQuery request, CancellationToken cancellationToken)
        {
            var items = await _context.OrderRequests.Where(l => l.Id == request.OrderRequestId).FirstAsync();

            var services = items.Items.Select(o => o.Service!);

            return services.Where(x => x != null && x.Provider != null && x.Provider!.Id == request.ProviderId).ToList();
        }

    }
}
