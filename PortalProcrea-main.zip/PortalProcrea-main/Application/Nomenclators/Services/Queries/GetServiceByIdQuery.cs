﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Nomenclators.Services.Dto;

namespace Application.Nomenclators.Services.Queries
{
    public class GetServiceByIdQuery : IRequest<ServiceDto>
    {
        public int Id { get; init; }
      
    }

    public class GetServiceByIdQueryHandler : IRequestHandler<GetServiceByIdQuery, ServiceDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetServiceByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<ServiceDto> Handle(GetServiceByIdQuery request, CancellationToken cancellationToken)
        {
            var product = await _context.Services
            .SingleOrDefaultAsync(x => x.Id == request.Id);

           return _mapper.Map<ServiceDto>(product);
           
        }
    }

}
