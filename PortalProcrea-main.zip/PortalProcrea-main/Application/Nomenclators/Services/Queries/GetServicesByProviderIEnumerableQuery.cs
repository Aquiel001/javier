﻿using Application.Common.Interfaces;
using AutoMapper;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Services.Queries
{
    public class GetServicesByProviderIEnumerableQuery : IRequest<IEnumerable<Service>>
    {
        public int ProviderId { get; init; }
    }

    public class GetServicesIEnumerableQueryHandler : IRequestHandler<GetServicesByProviderIEnumerableQuery, IEnumerable<Service>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetServicesIEnumerableQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<IEnumerable<Service>> Handle(GetServicesByProviderIEnumerableQuery request, CancellationToken cancellationToken)
        {
            return await _context.Services
                .Where(x => x.Provider != null && x.Provider.Id == request.ProviderId)
                .Include(x => x.Provider)
                .ToListAsync();
        }
    }
}