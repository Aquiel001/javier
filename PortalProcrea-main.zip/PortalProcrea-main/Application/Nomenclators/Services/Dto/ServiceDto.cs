﻿using AutoMapper;
using Domain.Entities.Nomenclators;

namespace PortalProcrea.Application.Nomenclators.Services.Dto;

public class ServiceDto
{
    public int Id { get; set; }
    public string Name { get; set; } = default!;
    public string Code { get; set; } = default!;
    public bool New { get; set; }
    public bool ShowInMainView { get; set; }
    public bool Published { get; set; }
    public double Rating { get; set; }
    public bool Active { get; set; }
    public int ProviderId { get; set; }
    public string ProviderName { get; set; } = default!;
    public string ImagePath { get; set; } = default!;

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<Service, ServiceDto>()
                .ForMember(dst => dst.ProviderId, src => src.MapFrom(a => a.Provider.Id))
                .ForMember(dst => dst.ProviderName, src => src.MapFrom(a => a.Provider.Name));
        }
    }
}
