﻿using Application.Nomenclators.Country.Dto;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Country.Queries
{
    public class GetCountryByIdQuery : IRequest<CountryDto>
    {
        public int Id { get; init; }
    }

    public class GetCountryByIdQueryHandler : IRequestHandler<GetCountryByIdQuery, CountryDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetCountryByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<CountryDto> Handle(GetCountryByIdQuery request, CancellationToken cancellationToken)
        {
            var currency = await _context.Countries.SingleOrDefaultAsync(x => x.Id == request.Id);

            return _mapper.Map<CountryDto>(currency);

        }
    }
}
