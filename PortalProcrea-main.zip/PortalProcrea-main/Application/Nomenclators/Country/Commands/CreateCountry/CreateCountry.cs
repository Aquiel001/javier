﻿using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Nomenclators.Country.Commands.CreateCountry
{
    public record CreateCountryCommand : IRequest<int>
    {
        public string Name { get; set; } = string.Empty;
        public string ShortName { get; set; } = string.Empty;
        public bool Active { get; set; }
    }

    public class CreateCountryCommandHandler : IRequestHandler<CreateCountryCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public CreateCountryCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateCountryCommand request, CancellationToken cancellationToken)
        {


            var country = new Domain.Entities.Nomenclators.Country
            {
                Name = request.Name!,
                ShortName = request.ShortName!,
                Active = request.Active,
            };


            _context.Countries.Add(country);

            await _context.SaveChangesAsync(cancellationToken);

            return country.Id;
        }
    }
}
