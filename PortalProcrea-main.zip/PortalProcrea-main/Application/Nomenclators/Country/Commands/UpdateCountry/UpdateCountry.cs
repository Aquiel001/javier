﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Country.Commands.UpdateCountry
{
    public record UpdateCountryCommand : IRequest<int>
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string ShortName { get; set; } = string.Empty;
        public bool Active { get; set; }
    }

    public class UpdateCountryCommandHandler : IRequestHandler<UpdateCountryCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public UpdateCountryCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(UpdateCountryCommand request, CancellationToken cancellationToken)
        {
            var country = await _context.Countries.FirstOrDefaultAsync(x => x.Id == request.Id);

            if (country != null)
            {
                country.Id = request.Id;
                country.Name = request.Name!;
                country.ShortName = request.ShortName!;
                country.Active = request.Active;

                _context.Countries.Update(country);

                await _context.SaveChangesAsync(cancellationToken);

                return country.Id;
            }
            return 0;
        }
    }
}
