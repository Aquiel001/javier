﻿using AutoMapper;

namespace Application.Nomenclators.Country.Dto
{
    public class CountryDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string ShortName { get; set; } = string.Empty;
        public bool Active { get; set; }

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Domain.Entities.Nomenclators.Country, CountryDto>();
            }
        }
    }
}
