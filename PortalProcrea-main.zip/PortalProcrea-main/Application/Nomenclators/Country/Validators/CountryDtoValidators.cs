﻿using Application.Nomenclators.Country.Dto;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Country.Validators
{
    public class CountryDtoValidators : AbstractValidator<CountryDto>
    {
        private readonly IApplicationDbContext _context;
        public CountryDtoValidators(IApplicationDbContext context)
        {
            _context = context;

            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(50)
                .Must(IsNameUnique)
                .WithMessage("El país ya existe");

            RuleFor(vm => vm.ShortName)
                .NotEmpty()
                .Must(IsShortNameUnique)
                .WithMessage("Las siglas ya existen");
        }

        public bool IsNameUnique(CountryDto countrydto, string newValue)
        {
            var country = _context.Countries.FirstOrDefault(l => l.Name.Equals(newValue));
            return country == null;
        }

        public bool IsShortNameUnique(CountryDto countrydto, string newValue)
        {
            var country = _context.Countries.FirstOrDefault(l => l.ShortName.Equals(newValue));
            return country == null;
        }
    }
}
