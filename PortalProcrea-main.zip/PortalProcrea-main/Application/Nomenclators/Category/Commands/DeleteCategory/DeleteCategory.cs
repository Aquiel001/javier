﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Category.Commands.DeleteCategory
{
    public record DeleteCategoryCommand : IRequest<bool>
    {
        public int Id { get; set; }
    }

    public class DeleteCategoryCommandHandler : IRequestHandler<DeleteCategoryCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteCategoryCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteCategoryCommand request, CancellationToken cancellationToken)
        {
            var category = await _context.Categories.SingleOrDefaultAsync(x => x.Id == request.Id);

            if (category != null)
            {

                _context.Categories.Remove(category);

                return await _context.SaveChangesAsync(cancellationToken) == 1;
            }
            return false;
        }
    }
}
