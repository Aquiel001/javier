﻿using Application.Common.Interfaces;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Category.Commands.CreateCategory
{
    public record CreateCategoryCommand : IRequest<int>
    {
        public string Name { get; set; } = string.Empty;
        public bool Active { get; set; }
    }

    public class CreateCategoryCommandHandler : IRequestHandler<CreateCategoryCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;

        public CreateCategoryCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _contextFactory = contextFactory;
        }

        public async Task<int> Handle(CreateCategoryCommand request, CancellationToken cancellationToken)
        {
            var category = new Domain.Entities.Nomenclators.Category
            {
                Name = request.Name!,
                Active = request.Active,
            };

            using (var context = _contextFactory.CreateDbContext())
            {
                context.Categories.Add(category);
                await context.SaveChangesAsync(cancellationToken);
            }

            return category.Id;
        }
    }
}
