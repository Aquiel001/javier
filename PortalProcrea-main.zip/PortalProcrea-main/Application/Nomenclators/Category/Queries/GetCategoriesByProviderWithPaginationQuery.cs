﻿using Application.Common.Interfaces;
using Application.Nomenclators.Category.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Nomenclators.Category.Queries
{
    public class GetCategoriesByProviderWithPaginationQuery : IRequest<PaginatedList<CategoryDto>>
    {
        public int ProviderId { get; init; }
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetCategoriesByProviderWithPaginationQueryHandler : IRequestHandler<GetCategoriesByProviderWithPaginationQuery, PaginatedList<CategoryDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetCategoriesByProviderWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<CategoryDto>> Handle(GetCategoriesByProviderWithPaginationQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Categories.Where(x => x.Provider != null && x.Provider.Id == request.ProviderId)
                .Include(x => x.Provider)
                .OrderByDescending(x => x.Id)
                .ProjectTo<CategoryDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
            }
        }
    }
}
