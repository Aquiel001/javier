﻿using Application.Nomenclators.Category.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Nomenclators.Category.Queries
{
    public class GetCategoriesByProviderIdQuery : IRequest<List<CategoryDto>>
    {
        public int ProviderId { get; init; }
    }

    public class GetCategoriesByProviderIdQueryHandler : IRequestHandler<GetCategoriesByProviderIdQuery, List<CategoryDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetCategoriesByProviderIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<CategoryDto>> Handle(GetCategoriesByProviderIdQuery request, CancellationToken cancellationToken)
        {
            return await _context.Categories
                .Where(x => x.Provider != null && x.Provider.Id == request.ProviderId)
                .OrderBy(x => x.Name)
                .ProjectTo<CategoryDto>(_mapper.ConfigurationProvider)
                .ToListAsync();
        }
    }
}
