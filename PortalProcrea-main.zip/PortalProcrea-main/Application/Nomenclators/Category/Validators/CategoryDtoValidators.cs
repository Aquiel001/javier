﻿using Application.Nomenclators.Category.Dto;
using Application.Nomenclators.Country.Dto;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Category.Validators
{
    public class CategoryDtoValidators : AbstractValidator<CategoryDto>
    {
        private readonly IApplicationDbContext _context;
        public CategoryDtoValidators(IApplicationDbContext context) { 
            _context = context;

            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(50)
                .Must(IsNameUnique)
                .WithMessage("La categoría ya existe");

        }

        public bool IsNameUnique(CategoryDto categorydto, string newValue)
        {
            var category = _context.Categories.FirstOrDefault(l => l.Name.Equals(newValue));
            return category == null;
        }
    }
}
