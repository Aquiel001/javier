﻿using AutoMapper;

namespace Application.Nomenclators.Category.Dto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public bool Active { get; set; }
        public string ProviderName { get; set; } = string.Empty;

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Domain.Entities.Nomenclators.Category, CategoryDto>()
                    .ForMember(dst => dst.ProviderName, src => src.MapFrom(a => a.Provider!.Name));
            }
        }
    }
}
