﻿using Application.Nomenclators.Providers.Dto;
using Domain.Entities.Nomenclators;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Providers.Validators
{
    public class ProviderDtoValidator : AbstractValidator<ProviderDto>
    {
        private readonly IApplicationDbContext _context;
        public ProviderDtoValidator(IApplicationDbContext context)
        {
            _context = context;

            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(30)
                .Must(IsNameUnique)
                .WithMessage("El proveedor ya existe");

            RuleFor(vm => vm.Code)
                .NotEmpty()
                .MaximumLength(30);
        }

        public bool IsNameUnique(ProviderDto providerDto, string newValue)
        {
            Provider provider = _context.Providers.FirstOrDefault(l => l.Name.Equals(newValue));

            return provider == null;
        }
    }
}



