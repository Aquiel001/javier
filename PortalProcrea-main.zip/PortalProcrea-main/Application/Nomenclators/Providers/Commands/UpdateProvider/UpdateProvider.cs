﻿using Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Providers.Commands.UpdateProvider
{
    public record UpdateProviderCommand : IRequest<bool>
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string Code { get; set; } = string.Empty;
        public string LogoPath { get; set; } = string.Empty;
        public string? LogoExt { get; set; }
        public bool Active { get; set; }
    }

    public class UpdateProviderCommandHandler : IRequestHandler<UpdateProviderCommand, bool>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;

        public UpdateProviderCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _contextFactory = contextFactory;
        }

        public async Task<bool> Handle(UpdateProviderCommand request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                var provider = await context.Providers.FirstOrDefaultAsync(x => x.Id == request.Id);

                if (provider != null)
                {
                    provider.Id = request.Id;
                    provider.Name = request.Name!;
                    provider.Code = request.Code!;
                    provider.Active = request.Active;
                    provider.LogoPath = request.LogoPath;

                    context.Providers.Update(provider);

                    return await _context.SaveChangesAsync(cancellationToken) > 0 ? true : false;
                }
                return false;
            }
        }
    }
}

