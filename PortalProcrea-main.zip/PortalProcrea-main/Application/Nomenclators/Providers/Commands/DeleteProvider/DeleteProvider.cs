﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Providers.Commands.DeleteProvider
{
    public record DeleteProviderCommand : IRequest<bool>
    {
        public int Id { get; set; }
    }

    public class DeleteProviderCommandHandler : IRequestHandler<DeleteProviderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteProviderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteProviderCommand request, CancellationToken cancellationToken)
        {
            var provider = await _context.Providers.SingleOrDefaultAsync(x => x.Id == request.Id);

            if (provider != null)
            {

                _context.Providers.Remove(provider);

                return await _context.SaveChangesAsync(cancellationToken) == 1;
            }
            return false;
        }
    }
}

