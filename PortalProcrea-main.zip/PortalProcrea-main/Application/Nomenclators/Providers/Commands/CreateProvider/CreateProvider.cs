﻿using Domain.Entities.Nomenclators;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Providers.Commands.CreateProvider
{
    public record CreateProviderCommand : IRequest<bool>
    {
        public string? Name { get; init; }
        public string? Code { get; init; }
        public bool Active { get; set; }
        public string? LogoPath { get; init; }
    }

    public class CreateProviderCommandHandler : IRequestHandler<CreateProviderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public CreateProviderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(CreateProviderCommand request, CancellationToken cancellationToken)
        {
            var entity = new Provider
            {
                Name = request.Name!,
                Code = request.Code!,
                Active = true,
                LogoPath = request.LogoPath!,
            };

            _context.Providers.Add(entity);

            return await _context.SaveChangesAsync(cancellationToken) > 0 ? true : false;
        }
    }
}
