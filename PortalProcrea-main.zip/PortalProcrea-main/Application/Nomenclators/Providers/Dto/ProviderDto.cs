﻿using AutoMapper;
using Domain.Entities.Nomenclators;

namespace Application.Nomenclators.Providers.Dto
{
    public class ProviderDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = default!;
        public string Code { get; set; } = default!;
        public string LogoPath { get; set; } = "img/default-image.png";
        public bool Active { get; set; }


        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Provider, ProviderDto>();
            }
        }
    }
}
