﻿using Application.Nomenclators.Providers.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Nomenclators.Providers.Queries
{
    public class GetProvidersWithPaginationQuery : IRequest<PaginatedList<ProviderDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetProvidersWithPaginationQueryHandler : IRequestHandler<GetProvidersWithPaginationQuery, PaginatedList<ProviderDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetProvidersWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<ProviderDto>> Handle(GetProvidersWithPaginationQuery request, CancellationToken cancellationToken)
        {
            return await _context.Providers
                .OrderBy(x => x.Id)
                .ProjectTo<ProviderDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}