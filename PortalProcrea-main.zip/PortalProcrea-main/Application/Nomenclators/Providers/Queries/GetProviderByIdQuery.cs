﻿using Application.Nomenclators.Providers.Dto;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Providers.Queries
{
    public class GetProviderByIdQuery : IRequest<ProviderDto>
    {
        public int Id { get; init; }

    }

    public class GetProviderByIdQueryHandler : IRequestHandler<GetProviderByIdQuery, ProviderDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetProviderByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<ProviderDto> Handle(GetProviderByIdQuery request, CancellationToken cancellationToken)
        {
            var provider = await _context.Providers
            .SingleOrDefaultAsync(x => x.Id == request.Id);

            return _mapper.Map<ProviderDto>(provider);

        }
    }

}
