﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Currency.Commands.UpdateCurrency
{
    public record UpdateCurrencyCommand : IRequest<int>
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string CurrencyCode { get; set; } = string.Empty;
        public double Rate { get; set; }
        public bool Active { get; set; }
    }

    public class UpdateCurrencyCommandHandler : IRequestHandler<UpdateCurrencyCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public UpdateCurrencyCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(UpdateCurrencyCommand request, CancellationToken cancellationToken)
        {
            var currency = await _context.Currencies.FirstOrDefaultAsync(x => x.Id == request.Id);

            if (currency != null)
            {
                currency.Id = request.Id;
                currency.Name = request.Name!;
                currency.CurrencyCode = request.CurrencyCode!;
                currency.Rate = request.Rate;
                currency.Active = request.Active;

                _context.Currencies.Update(currency);

                await _context.SaveChangesAsync(cancellationToken);

                return currency.Id;
            }
            return 0;
        }
    }
}