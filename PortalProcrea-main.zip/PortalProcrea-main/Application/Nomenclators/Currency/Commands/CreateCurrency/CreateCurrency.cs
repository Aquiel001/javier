﻿using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Currency.Commands.CreateCurrency
{
    public record CreateCurrencyCommand : IRequest<int>
    {
        public string Name { get; set; } = string.Empty;
        public string CurrencyCode { get; set; } = string.Empty;
        public double Rate { get; set; }
        public bool Active { get; set; }
    }

    public class CreateCurrencyCommandHandler : IRequestHandler<CreateCurrencyCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public CreateCurrencyCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateCurrencyCommand request, CancellationToken cancellationToken)
        {


            var currency = new Domain.Entities.Nomenclators.Currency
            {
                Name = request.Name!,
                CurrencyCode = request.CurrencyCode!,
                Rate = request.Rate,
                Active = request.Active,
            };
            

            _context.Currencies.Add(currency);

            await _context.SaveChangesAsync(cancellationToken);

            return currency.Id;
        }
    }
}