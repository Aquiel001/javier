﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Currency.Commands.DeleteCurrency
{
    public record DeleteCurrencyCommand : IRequest<bool>
    {
        public int Id { get; set; }
    }

    public class DeleteCurrencyCommandHandler : IRequestHandler<DeleteCurrencyCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public DeleteCurrencyCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(DeleteCurrencyCommand request, CancellationToken cancellationToken)
        {
            var currency = await _context.Currencies.SingleOrDefaultAsync(x => x.Id == request.Id);

            if (currency != null)
            {

                _context.Currencies.Remove(currency);

                return await _context.SaveChangesAsync(cancellationToken) == 1;
            }
            return false;
        }
    }
}