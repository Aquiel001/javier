﻿using Application.Nomenclators.Currency.Dto;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;
using Domain.Entities.Nomenclators;

namespace Application.Nomenclators.Currency.Validators
{
    public class CurrencyDtoValidators : AbstractValidator<CurrencyDto>
    {
        private readonly IApplicationDbContext _context;
        
        public CurrencyDtoValidators(IApplicationDbContext context)
        {
            _context = context;

            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(50)
                .Must(IsNameUnique)
                .WithMessage("La moneda ya existe");

            RuleFor(vm => vm.CurrencyCode)
                .NotEmpty();
        }

        public bool IsNameUnique(CurrencyDto currencydto, string newValue)
        {
            var currency = _context.Currencies.FirstOrDefault(l => l.Name.Equals(newValue));
            return currency == null;
        }
    }
}
