﻿using AutoMapper;
using Domain.Entities.Nomenclators;

namespace Application.Nomenclators.Currency.Dto
{
    public class CurrencyDto
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string CurrencyCode { get; set; } = string.Empty;
        public double Rate { get; set; }
        public bool Active { get; set; }

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Domain.Entities.Nomenclators.Currency, CurrencyDto>();
            }
        }
    }
}
