﻿using Application.Nomenclators.Currency.Dto;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Currency.Queries
{
    public class GetCurrencyByIdQuery : IRequest<CurrencyDto>
    {
        public int Id { get; init; }

    }

    public class GetCurrencyByIdQueryHandler : IRequestHandler<GetCurrencyByIdQuery, CurrencyDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetCurrencyByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<CurrencyDto> Handle(GetCurrencyByIdQuery request, CancellationToken cancellationToken)
        {
            var currency = await _context.Currencies.SingleOrDefaultAsync(x => x.Id == request.Id);

            return _mapper.Map<CurrencyDto>(currency);

        }
    }
}
