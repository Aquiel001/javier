﻿using Application.Nomenclators.Currency.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Nomenclators.Currency.Queries
{
    public class GetCurrenciesWithPaginationQuery : IRequest<PaginatedList<CurrencyDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetCurrenciesWithPaginationQueryHandler : IRequestHandler<GetCurrenciesWithPaginationQuery, PaginatedList<CurrencyDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetCurrenciesWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<CurrencyDto>> Handle(GetCurrenciesWithPaginationQuery request, CancellationToken cancellationToken)
        {
            return await _context.Currencies
                .OrderByDescending(x => x.Id)
                .ProjectTo<CurrencyDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
