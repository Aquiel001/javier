﻿using Application.Nomenclators.Customers.Commands.CreateCustomer;
using Domain.Entities.Nomenclators;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Nomenclators.Customers.Commands.CreateCustomer
{
    public record CreateCustomerCommand : IRequest<int>
    {
        public string UserId { get; init; } = string.Empty;
        public string Name { get; init; } = string.Empty;
        public string LastName { get; init; } = string.Empty;
        public string Email { get; init; } = string.Empty;
        public string? Code { get; init; }
        public bool IsCompany { get; set; }
        public string? BankAccount { get; set; }
        public int CountryId { get; set; }
        public int CurrentCurrencyId { get; set; }
    }

    public class CreateCustomerCommandHandler : IRequestHandler<CreateCustomerCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public CreateCustomerCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateCustomerCommand request, CancellationToken cancellationToken)
        {
            var customer = new Customer(request.UserId, request.Name, request.LastName, request.Email);

            customer.CountryId = request.CountryId;
            customer.CurrentCurrencyId = request.CurrentCurrencyId;
            customer.IsCompany = request.IsCompany;

            if (!string.IsNullOrWhiteSpace(request.BankAccount))
                customer.BankAccount = request.BankAccount;
          
            if (!string.IsNullOrWhiteSpace(request.Code))
                customer.CodeNit = request.Code;
           
            _context.Customers.Add(customer);

            await _context.SaveChangesAsync(cancellationToken);

            return customer.Id;
        }
    }
}
