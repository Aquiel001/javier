﻿using Application.Common.Interfaces;
using Application.Nomenclators.Products.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Nomenclators.Products.Queries;

namespace Application.Nomenclators.Products.Queries
{
    public class GetNewProductsQuery : IRequest<List<ProductDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetNewProductsQueryHandler : IRequestHandler<GetNewProductsQuery, List<ProductDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetNewProductsQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<List<ProductDto>> Handle(GetNewProductsQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Products
                .Where(x => x.New)
                .ProjectTo<ProductDto>(_mapper.ConfigurationProvider)
                .ToListAsync();
            }
        }
    }
}
