﻿using Application.Common.Interfaces;
using Application.Nomenclators.Products.Dto;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace PortalProcrea.Application.Nomenclators.Products.Queries;

public class GetProductsWithPaginationQuery : IRequest<PaginatedList<ProductDto>>
{
    public int PageNumber { get; init; } = 1;
    public int PageSize { get; init; } = 10;
}

public class GetProductsWithPaginationQueryHandler : IRequestHandler<GetProductsWithPaginationQuery, PaginatedList<ProductDto>>
{
    private readonly IApplicationDbContext _context;
    private readonly IMapper _mapper;
    private readonly IApplicationDbContextFactory _contextFactory;

    public GetProductsWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
    {
        _context = context;
        _mapper = mapper;
        _contextFactory = contextFactory;
    }

    public async Task<PaginatedList<ProductDto>> Handle(GetProductsWithPaginationQuery request, CancellationToken cancellationToken)
    {
        using (var context = _contextFactory.CreateDbContext())
        {
            return await context.Products
            .Include(x => x.Provider)
            .OrderByDescending(x => x.Id)
            .ProjectTo<ProductDto>(_mapper.ConfigurationProvider)
            .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
