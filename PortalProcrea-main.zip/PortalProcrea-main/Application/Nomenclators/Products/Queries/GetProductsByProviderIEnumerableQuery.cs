﻿using Application.Common.Interfaces;
using AutoMapper;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Products.Queries
{
    public class GetProductsByProviderIEnumerableQuery : IRequest<IEnumerable<Product>>
    {
        public int ProviderId { get; init; }
    }

    public class GetProductsIEnumerableQueryHandler : IRequestHandler<GetProductsByProviderIEnumerableQuery, IEnumerable<Product>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetProductsIEnumerableQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<IEnumerable<Product>> Handle(GetProductsByProviderIEnumerableQuery request, CancellationToken cancellationToken)
        {
            return await _context.Products
                .Where(x => x.Provider != null && x.Provider.Id == request.ProviderId)
                .Include(x => x.Provider)
                .ToListAsync();
        }
    }
}