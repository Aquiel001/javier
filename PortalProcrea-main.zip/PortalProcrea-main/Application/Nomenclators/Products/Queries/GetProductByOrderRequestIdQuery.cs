﻿using Application.Common.Interfaces;
using AutoMapper;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Products.Queries
{
    public class GetProductByOrderRequestIdQuery : IRequest<IEnumerable<Product>>
    {
        public int OrderRequestId {  get; set; }
        public int ProviderId { get; init; }

    }

    public class GetProductByOrderRequestIdQueryHandler : IRequestHandler<GetProductByOrderRequestIdQuery, IEnumerable<Product>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetProductByOrderRequestIdQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<IEnumerable<Product>> Handle(GetProductByOrderRequestIdQuery request, CancellationToken cancellationToken)
        {
            var items = await _context.OrderRequests.Where(l => l.Id == request.OrderRequestId).FirstAsync();

            var product = items.Items.Select(o => o.Product!);

            return product.Where(x => x != null && x.Provider != null && x.Provider!.Id == request.ProviderId).ToList();
        }

    }
}
