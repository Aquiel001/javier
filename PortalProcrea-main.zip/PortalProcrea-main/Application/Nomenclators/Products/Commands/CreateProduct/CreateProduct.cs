﻿using Application.Common.Interfaces;
using Domain.Entities.Nomenclators;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Nomenclators.Products.Commands.CreateProduct;

public record CreateProductCommand : IRequest<int>
{
    public string? Name { get; init; }
    public string? Code { get; init; }
    public bool New { get; set; }
    public bool ShowInMainView { get; set; }
    public bool Published { get; set; }
    public bool Active { get; set; }
    public string? ImagePath { get; set; }
    public double Rating { get; set; }
    public int AmountMin { get; set; }
}

public class CreateProductCommandHandler : IRequestHandler<CreateProductCommand, int>
{
    private readonly IApplicationDbContext _context;
    private readonly IApplicationDbContextFactory _contextFactory;

    public CreateProductCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
    {
        _context = context;
        _contextFactory = contextFactory;
    }

    public async Task<int> Handle(CreateProductCommand request, CancellationToken cancellationToken)
    {
        var entity = new Product
        {
            Name = request.Name!,
            Code = request.Code!,
            New = request.New,
            Active = request.Active,
            Published = request.Published,
            ShowInMainView = request.ShowInMainView,
            ImagePath = request.ImagePath!,
            Rating = request.Rating,
        };

        using (var context = _contextFactory.CreateDbContext())
        {
            context.Products.Add(entity);
            await context.SaveChangesAsync(cancellationToken);
        }

        return entity.Id;
    }
}
