﻿using Application.Common.Interfaces;
using Domain.Entities.Nomenclators;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Products.Commands.UpdateProduct
{
    public record UpdateProductCommand : IRequest<int>
    {
        public int Id { get; set; }
        public string? Name { get; init; }
        public string? Code { get; init; }
        public bool New { get; set; }
        public bool ShowInMainView { get; set; }
        public bool Published { get; set; }
        public double Rating { get; set; }
        public bool Active { get; set; }
        public string? ImagePath { get; init; }
        public int AmountMin { get; set; }
    }

    public class UpdateProductCommandHandler : IRequestHandler<UpdateProductCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;

        public UpdateProductCommandHandler(IApplicationDbContext context, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _contextFactory = contextFactory;
        }

        public async Task<int> Handle(UpdateProductCommand request, CancellationToken cancellationToken)
        {
            var product = await _context.Products.FirstOrDefaultAsync(x => x.Id == request.Id);

            if (product != null)
            {
                var entity = new Product
                {
                    Id = request.Id,
                    Name = request.Name!,
                    Code = request.Code!,
                    New = request.New,
                    ShowInMainView = request.ShowInMainView,
                    Published = request.Published,
                    Rating = request.Rating,
                    Active = request.Active,
                    ImagePath = request.ImagePath!
                };

                using (var context = _contextFactory.CreateDbContext())
                {
                    context.Products.Update(entity);
                    await context.SaveChangesAsync(cancellationToken);
                }

                return product.Id;
            }
            return 0;
        }
    }
}
