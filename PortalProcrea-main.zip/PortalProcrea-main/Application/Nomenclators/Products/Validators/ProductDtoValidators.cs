﻿using Application.Nomenclators.Products.Dto;
using Domain.Entities.Nomenclators;
using FluentValidation;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Nomenclators.Products.Validators
{
    public class ProductDtoValidators : AbstractValidator<ProductDto>
    {
        private readonly IApplicationDbContext _context;
        public ProductDtoValidators(IApplicationDbContext context)
        {
            _context = context;

            RuleFor(vm => vm.Name)
                .NotEmpty()
                .MaximumLength(50)
                .Must(IsNameUnique)
                .WithMessage("El producto ya existe");

            RuleFor(vm => vm.Code)
                .NotEmpty()
                .MaximumLength(30);
        }

        public bool IsNameUnique(ProductDto productDto, string newValue)
        {
            Product product = _context.Products.FirstOrDefault(l => l.Name.Equals(newValue));

            return product == null;
        }
    }
}
