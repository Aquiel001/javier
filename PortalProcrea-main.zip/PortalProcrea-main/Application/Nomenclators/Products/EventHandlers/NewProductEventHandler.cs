﻿using Application.Common.Interfaces;
using Application.Common.Messages.Mail;
using Application.Orders.EventHandlers;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Nomenclators.Products.EventHandlers
{
    public class NewProductEventHandler : INotificationHandler<ProductNewEvent>
    {
        private readonly ILogger<NewProductEventHandler> _logger;
        private readonly IQueue<EmailMessage> _queue;
        private readonly IApplicationDbContext _dbContext;

        public NewProductEventHandler(ILogger<NewProductEventHandler> logger,/* IEmailSender emailSender,*/ IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(ProductNewEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after a product was marked as new.");

            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();
            string toAddress = "adurandbazan@gmail.com";
            string toName = "Alejandro";
            string fromAddress = "portalprocrea@mail.com";
            string fromName = "Portal Procrea";

           
            var email = new EmailMessage 
            {
                EmailAccount= eamailAccount,
                FromAddress= fromAddress,
                FromName= fromName,
                ToAddress= toAddress,
                ToName= toName,
                Subject = "New Product",
                Body = "<p> <b>New product</b> has been enterd, please see the details in the web page.</p>"

            };

            _queue.Enqueue(email);
            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}