﻿using AutoMapper;
using Domain.Entities.Nomenclators;

namespace Application.Nomenclators.Products.Dto;

public class ProductDto
{
    public int Id { get; set; }
    public string Name { get; set; } = default!;
    public string Code { get; set; } = default!;
    public string ImagePath { get; set; } = "default-image.png";
    public bool New { get; set; }
    public bool ShowInMainView { get; set; }
    public bool Published { get; set; }
    public double Rating { get; set; }
    public bool Active { get; set; }
    public int ProviderId { get; set; }
    public string ProviderName { get; set; } = string.Empty;
    public int AmountMin { get; set; }

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<Product, ProductDto>()
                .ForMember(dst => dst.ProviderId, src => src.MapFrom(a => a.Provider != null ? a.Provider.Id : 0))
                .ForMember(dst => dst.ProviderName, src => src.MapFrom(a => a.Provider != null ? a.Provider.Name : ""));
        }
    }
}
