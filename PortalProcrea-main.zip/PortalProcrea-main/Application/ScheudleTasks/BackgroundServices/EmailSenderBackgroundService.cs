﻿using Application.Common.Interfaces;
using Domain.Entities.Messages;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Application.ScheudleTasks.BackgroundServices
{
    public class EmailSenderBackgroundService : BackgroundService
    {
        private readonly IServiceProvider _serviceProvider;

        public EmailSenderBackgroundService(IServiceProvider serviceProvider)
        {
           _serviceProvider = serviceProvider;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            using var scope = _serviceProvider.CreateScope();
            var _queue = scope.ServiceProvider.GetRequiredService<IQueue<EmailMessage>>();
            var _emailSender = scope.ServiceProvider.GetRequiredService<IEmailSender>();

            while (!stoppingToken.IsCancellationRequested)
            {
                int emailsCount = _queue.Emails.Count(x => x.FailAttemptsCount <= 5);


                for (int i = 0; i < emailsCount; i++)
                {
                    var email = _queue.Dequeue();

                    if (email is not null)
                    {

                        try
                        {
                            await _emailSender.SendEmailAsync(email);
                        }
                        catch (Exception)
                        {
                            email.FailAttemptsCount++;
                            _queue.Enqueue(email);
                        }
                    }

                }
             
                await _queue.SaveChangesAsync(stoppingToken);

               await Task.Delay(60000, stoppingToken);

            }
        }
    }
}