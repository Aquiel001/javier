﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Application.Common.Interfaces;
using Domain.Entities.Orders;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PortalProcrea.Application.Common.Interfaces;
using System.Timers;

namespace Application.ScheudleTasks.OrderExpiredService
{
    public class OrderExpiredService : IHostedService, IDisposable
    {
        private readonly ILogger _logger;
        private System.Timers.Timer _timer;
        private readonly IApplicationDbContextFactory _contextFactory;
        private readonly IConfiguration _configuration;
        private readonly IApplicationDbContext _context;

        public OrderExpiredService(ILogger<OrderExpiredService> logger, IApplicationDbContextFactory contextFactory,
            IConfiguration configuration, IApplicationDbContext context)
        {
            _logger = logger;
            _contextFactory = contextFactory;
            _configuration = configuration;
            _context = context;
        }
        public Task StartAsync(CancellationToken cancellationToken)
        {
            _timer = new System.Timers.Timer(12 * 60 * 60 * 1000);
            _timer.Elapsed += async (sender, e) => await ExecuteTaskAsync(cancellationToken);
            _timer.Start();
            return Task.CompletedTask;
        }

        private async Task ExecuteTaskAsync(CancellationToken cancellationToken)
        {
            int fechaExpiracion = int.Parse(_configuration["OrderExpiredDate"]!);

            using (var context = _contextFactory.CreateDbContext())
            {
                DbSet<Order> Order = context.Orders;

                foreach (var order in Order) { 
                    if(order.LastModified.AddDays(fechaExpiracion) < DateTime.UtcNow)
                    {
                        order.OrderStatus = Domain.Enums.OrderStatus.Expired;
                        
                        context.Orders.Update(order);

                        await context.SaveChangesAsync(cancellationToken);
                    }
                }
                     
            }

            _logger.LogInformation("tarea programada ejecutada");
        }
        public Task StopAsync(CancellationToken cancellationToken)
        {
            _timer.Stop();
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
