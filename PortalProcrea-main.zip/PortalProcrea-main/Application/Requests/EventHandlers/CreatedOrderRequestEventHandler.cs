﻿using Application.Common.Interfaces;
using Application.Common.Security;
using Application.MessageTemplates.Queries;
using Application.Orders.EventHandlers;
using Domain.Constants;
using Domain.Entities.Messages;
using Domain.Entities.Nomenclators;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Org.BouncyCastle.Math.EC.Rfc7748;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Requests.EventHandlers
{
    internal class CreatedOrderRequestEventHandler : INotificationHandler<CreatedOrderRequestEvent>
    {
        private readonly ILogger<CreatedOrderRequestEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public CreatedOrderRequestEventHandler(ILogger<CreatedOrderRequestEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(CreatedOrderRequestEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after the client made the order request.");

           var template = await _mediator.Send(new GetMessageTemplateByNameQuery 
           { 
                Name = MessageTemplateSystemNames.NewOrderRequestMessage
           });

            var providerId = notification.OrderRequest.ProviderId;
            
            var users = await _identityService.GetUsersByProviderAsync(providerId);

            UserDto? admin = null;
           
                foreach (var user in users)
                {
                    bool isAdmin = await _identityService.IsInRoleAsync(user.Id, Roles.Administrator);
                    if (isAdmin) 
                    {
                       admin = user;
                       break;
                    }
                }

                var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();
                string? cc = string.Join(", ", users.Where(x => x.Id != admin!.Id).Select(x => x.Email));
           
             _queue.Enqueue(new EmailMessage
             {
                    EmailAccount = eamailAccount,
                    FromAddress = eamailAccount.Username,
                    FromName = eamailAccount.DisplayName,
                    ToAddress = admin!.Email,
                    ToName = admin.Name,
                    Subject = template!.Subject,
                    Body = template.Body,
                    CC = cc
             });
          
           await _queue.SaveChangesAsync(cancellationToken);
           
        }
    }
}