﻿using Application.Requests.Dtos.Resolvers;
using AutoMapper;
using Domain.Entities.Nomenclators;
using Domain.Entities.Requests;

namespace Application.Requests.Dtos
{
    public class OrderRequestDto
    {
        public int Id { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string CustomerLastName { get; set; } = string.Empty;
        public int OrderRequestStatusId { get; set; }
        public int QuantityOffers { get; set; }
        public List<OrderRequestItemDto> Items { get; set; } = new();

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<OrderRequest, OrderRequestDto>()
                    .ForMember(dst => dst.CustomerName, src => src.MapFrom(a => a.Customer.Name))
                    .ForMember(dst => dst.CustomerLastName, src => src.MapFrom(a => a.Customer.LastName));
                    //.ForMember(dst => dst.QuantityOffers, src => src.MapFrom<QuantityOffersByOrderRequestFieldResolver>());

                CreateMap<OrderRequestItem, OrderRequestItemDto>()
                    .ForMember(dst => dst.ProductName, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.Name : ""))
                    .ForMember(dst => dst.ProductImagePath, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.ImagePath : ""))
                    .ForMember(dst => dst.ProductProviderId, src => src.MapFrom(a => a.Product!.Provider!.Id))
                    .ForMember(dst => dst.ServiceName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Name : ""))
                    .ForMember(dst => dst.ServiceImagePath, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.ImagePath : ""))
                    .ForMember(dst => dst.ServiceProviderId, src => src.MapFrom(a => a.Service!.Provider!.Id));
                ;
            }
        }
    }
}
