﻿using Application.Common.Interfaces;
using AutoMapper;
using Domain.Entities.Requests;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace Application.Requests.Dtos.Resolvers
{
    public class QuantityOffersByOrderRequestFieldResolver : IValueResolver<OrderRequest, OrderRequestDto, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IUser _users;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContextFactory _contextFactory;

        public QuantityOffersByOrderRequestFieldResolver(IApplicationDbContext context, IMapper mapper, IUser users, IIdentityService identityService, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _users = users;
            _identityService = identityService;
            _contextFactory = contextFactory;
        }

        public int Resolve(OrderRequest source, OrderRequestDto destination, int destMember, ResolutionContext context)
        {
            var userId = _users.Id;

            using (var contexto = _contextFactory.CreateDbContext())
            {
                if (_identityService.IsInRoleAsync(userId!, "Administrator").GetAwaiter().GetResult())
                {

                    return contexto.Offers.Count(x => x.OrderRequest != null && x.OrderRequest.Id == source.Id);
                }
                else
                {
                    return contexto.Offers.Count(x => x.OrderRequest != null && x.OrderRequest.Id == source.Id && x.Provider != null && x.Provider.Id == _users.Provider!.Id);
                }
            }
        }
    }
}
