﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Requests.Dtos
{
    public class OrderRequestItemDto
    {
        public int? ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string ProductImagePath { get; set; } = string.Empty;
        public int? ProductProviderId { get; set; }
        public int? ServiceId { get; set; }
        public string ServiceName { get; set; } = string.Empty;
        public string ServiceImagePath { get; set; } = string.Empty;
        public int? ServiceProviderId { get; set; }
        public decimal Quantity { get; set; }
    }
}
