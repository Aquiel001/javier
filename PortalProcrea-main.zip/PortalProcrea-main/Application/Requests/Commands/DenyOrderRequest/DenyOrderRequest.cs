﻿using Application.Requests.Dtos;
using Domain.Entities.Requests;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Requests.Commands.DenyOrderRequest
{
    public class DenyOrderRequestCommand : IRequest<int>
    {
        public int Id { get; set; }
    }

    public class DenyOrderRequestCommandHandler : IRequestHandler<DenyOrderRequestCommand, int>
    {
        private readonly IApplicationDbContext _context;

        public DenyOrderRequestCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(DenyOrderRequestCommand request, CancellationToken cancellationToken)
        {
            var orderRequest = _context.OrderRequests.FirstOrDefault(x => x.Id == request.Id);

            if (orderRequest != null)
            {
                orderRequest.OrderRequestStatusId = 30;
                _context.OrderRequests.Update(orderRequest);
                await _context.SaveChangesAsync(cancellationToken);

                return orderRequest.Id;
            }
            return 0;
        }
    }
}
