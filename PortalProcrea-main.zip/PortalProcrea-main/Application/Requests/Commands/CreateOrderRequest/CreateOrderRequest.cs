﻿using Application.Requests.Dtos;
using Domain.Entities.Nomenclators;
using Domain.Entities.Requests;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Requests.Commands.CreateRequest
{
    public class CreateOrderRequestCommand : IRequest<int>
    {
       // public int CustomerId { get; set; }
        public int ProviderId { get; set; }
        public List<OrderRequestItemDto> OrderRequestItems { get; set; } = new();
    }

    public class CreateOrderRequestCommandHandler : IRequestHandler<CreateOrderRequestCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IUser _user;

        public CreateOrderRequestCommandHandler(IApplicationDbContext context, IUser user)
        {
            _context = context;
            _user = user;
        }

        public async Task<int> Handle(CreateOrderRequestCommand request, CancellationToken cancellationToken)
        {
            Customer customer = await _context.Customers.SingleAsync(x => x.UserId == _user.Id);

            var orderRequest = new OrderRequest
            {
                CustomerId = customer.Id,
                ProviderId = request.ProviderId,
                Items = request.OrderRequestItems.Select(item => new OrderRequestItem
                {
                    ProductId = item.ProductId,
                    ServiceId = item.ServiceId,
                    Quantity = item.Quantity
                }).ToList()
            };

            //adding domain event CreatedOrderRequestEvent
            orderRequest.AddDomainEvent(new CreatedOrderRequestEvent(orderRequest));
            
            _context.OrderRequests.Add(orderRequest);

            await _context.SaveChangesAsync(cancellationToken);

            return orderRequest.Id;

        }
    }
}
