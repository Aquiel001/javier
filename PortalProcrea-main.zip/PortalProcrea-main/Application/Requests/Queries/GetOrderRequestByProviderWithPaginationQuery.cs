﻿using Application.Common.Interfaces;
using Application.Requests.Dtos;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Requests.Queries
{
    public class GetOrderRequestByProviderWithPaginationQuery : IRequest<PaginatedList<OrderRequestDto>>
    {
        public int ProviderId { get; set; }
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetOrderRequestByProviderWithPaginationQueryHandler : IRequestHandler<GetOrderRequestByProviderWithPaginationQuery, PaginatedList<OrderRequestDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetOrderRequestByProviderWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<OrderRequestDto>> Handle(GetOrderRequestByProviderWithPaginationQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.OrderRequests
                        .Where(l => l.Provider != null && l.Provider.Id == request.ProviderId)
                        .Include(x => x.Provider)
                        .OrderByDescending(x => x.Id)
                        .ProjectTo<OrderRequestDto>(_mapper.ConfigurationProvider)
                        .PaginatedListAsync(request.PageNumber, request.PageSize);
            }
        }
    }
}
