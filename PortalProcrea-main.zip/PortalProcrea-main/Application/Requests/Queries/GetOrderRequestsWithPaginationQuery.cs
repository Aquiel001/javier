﻿using Application.Requests.Dtos;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Requests.Queries
{
    public class GetOrderRequestsWithPaginationQuery : IRequest<PaginatedList<OrderRequestDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetOrderRequestsWithPaginationQueryHandler : IRequestHandler<GetOrderRequestsWithPaginationQuery, PaginatedList<OrderRequestDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetOrderRequestsWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<PaginatedList<OrderRequestDto>> Handle(GetOrderRequestsWithPaginationQuery request, CancellationToken cancellationToken)
        {
            return await _context.OrderRequests
                .OrderByDescending(x => x.Id)
                .ProjectTo<OrderRequestDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
