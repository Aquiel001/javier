﻿using Application.Requests.Dtos;
using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Requests.Queries
{
    public class GetOrderRequestByIdQuery : IRequest<OrderRequestDto>
    {
        public int Id { get; set; }
    }

    public class GetOrderRequestByIdQueryHandler : IRequestHandler<GetOrderRequestByIdQuery, OrderRequestDto>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetOrderRequestByIdQueryHandler(IApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<OrderRequestDto> Handle(GetOrderRequestByIdQuery request, CancellationToken cancellationToken)
        {
            var orderRequest = await _context.OrderRequests.SingleOrDefaultAsync(x => x.Id == request.Id);

            return _mapper.Map<OrderRequestDto>(orderRequest);
        }
    }
}
