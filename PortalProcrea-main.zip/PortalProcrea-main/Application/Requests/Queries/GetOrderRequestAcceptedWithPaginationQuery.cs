﻿using Application.Common.Interfaces;
using Application.Requests.Dtos;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.Requests.Queries
{
    public class GetOrderRequestAcceptedWithPaginationQuery : IRequest<PaginatedList<OrderRequestDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetOrderRequestAcceptedWithPaginationQueryHandler : IRequestHandler<GetOrderRequestAcceptedWithPaginationQuery, PaginatedList<OrderRequestDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetOrderRequestAcceptedWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<OrderRequestDto>> Handle(GetOrderRequestAcceptedWithPaginationQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await _context.OrderRequests
                        .Where(l => l.OrderRequestStatusId == 20)
                        .OrderByDescending(x => x.Id)
                        .ProjectTo<OrderRequestDto>(_mapper.ConfigurationProvider)
                        .PaginatedListAsync(request.PageNumber, request.PageSize);
            }
        }
    }
}
