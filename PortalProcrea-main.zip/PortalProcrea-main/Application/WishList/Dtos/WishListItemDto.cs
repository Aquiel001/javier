﻿using Application.ShoppingCart.Dtos;
using AutoMapper;
using Domain.Entities.Cart;
using Domain.Entities.Nomenclators;
using Domain.Entities.WishList;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.WishList.Dtos
{
    public class WishListItemDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public int ServiceId { get; set; }
        public string ServiceName { get; set; } = string.Empty;
        
        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<WishListItemDto, WishListItem>();
                CreateMap<WishListItem, WishListItemDto>()
                    .ForMember(dst => dst.ProductName, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.Name : ""))
                    .ForMember(dst => dst.ServiceName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Name : ""));
            }
        }
    }
}
