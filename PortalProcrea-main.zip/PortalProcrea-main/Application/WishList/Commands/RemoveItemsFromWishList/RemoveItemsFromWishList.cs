﻿using Domain.Entities.WishList;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.WishList.Commands.RemoveItemsFromWishList
{
    public class RemoveItemsFromWishListCommand : IRequest<bool>
    {
        public List<int> ItemIds { get; set; } = new();
    }

    public class RemoveItemsFromWishListCommandHandler : IRequestHandler<RemoveItemsFromWishListCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public RemoveItemsFromWishListCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(RemoveItemsFromWishListCommand request, CancellationToken cancellationToken)
        {
            List<WishListItem> wishListItems = _context.WishListItems
                                                               .Where(x => request.ItemIds.Contains(x.Id)).ToList();


            _context.WishListItems.RemoveRange(wishListItems);

            return await _context.SaveChangesAsync(cancellationToken) == 1;
        }
    }
}
