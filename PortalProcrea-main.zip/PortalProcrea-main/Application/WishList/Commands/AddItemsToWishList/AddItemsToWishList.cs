﻿using Application.WishList.Commands.AddItemsToWishList;
using Application.WishList.Dtos;
using Domain.Entities.Cart;
using Domain.Entities.WishList;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.WishList.Commands.AddItemsToWishList
{
    public class AddItemsToWishListCommand : IRequest<List<int>>
    {
        public int CustomerId { get; set; }
        public List<WishListItemDto> Items { get; set; } = new();
    }

    public class AddItemsToWishListCommandHandler : IRequestHandler<AddItemsToWishListCommand, List<int>>
    {
        private readonly IApplicationDbContext _context;

        public AddItemsToWishListCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<List<int>> Handle(AddItemsToWishListCommand request, CancellationToken cancellationToken)
        {
            List<WishListItem> wishList = new();

            foreach (var item in request.Items)
            {
                var wishListItem = new WishListItem
                {
                    CustomerId = request.CustomerId,
                    ProductId = item.ProductId,
                    ServiceId = item.ServiceId

                };

                wishList.Add(wishListItem);
            }

            _context.WishListItems.AddRange(wishList);

            await _context.SaveChangesAsync(cancellationToken);

            return wishList.Select(x => x.Id).ToList();

        }
    }
}

