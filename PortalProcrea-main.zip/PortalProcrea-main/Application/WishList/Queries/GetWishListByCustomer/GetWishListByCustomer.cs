﻿using Application.WishList.Dtos;
using Application.WishList.Queries.GetWishListByCustomer;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.WishList.Queries.GetWishListByCustomer
{
    public class GetWishListByCustomerQuery : IRequest<PaginatedList<WishListItemDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetWishListByCustomerQueryHandler : IRequestHandler<GetWishListByCustomerQuery, PaginatedList<WishListItemDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IUser _user;

        public GetWishListByCustomerQueryHandler(IApplicationDbContext context, IMapper mapper, IUser user)
        {
            _context = context;
            _mapper = mapper;
            _user = user;
        }

        public async Task<PaginatedList<WishListItemDto>> Handle(GetWishListByCustomerQuery request, CancellationToken cancellationToken)
        {
            return await _context.WishListItems
                .Where(x => x.Customer!.UserId == _user.Id)
                .OrderByDescending(x => x.Id)
                .ProjectTo<WishListItemDto>(_mapper.ConfigurationProvider)
                .PaginatedListAsync(request.PageNumber, request.PageSize);
        }
    }
}
