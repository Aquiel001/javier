﻿using Application.Requests.Queries;
using AutoMapper;
using Domain.Entities.Messages;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.MessageTemplates.Queries
{
    public class GetMessageTemplateByNameQuery : IRequest<MessageTemplate?>
    {
        public string Name { get; set; } = string.Empty;
    }

    public class GetMessageTemplateByNameQueryHandler : IRequestHandler<GetMessageTemplateByNameQuery, MessageTemplate?>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;

        public GetMessageTemplateByNameQueryHandler(IApplicationDbContext context)
        {
            _context = context; 
        }

        public async Task<MessageTemplate?> Handle(GetMessageTemplateByNameQuery request, CancellationToken cancellationToken)
        {
            return await _context.MessageTemplates
                                 .FirstOrDefaultAsync(x => x.Name.Equals(request.Name));
               
        }
    }
}
