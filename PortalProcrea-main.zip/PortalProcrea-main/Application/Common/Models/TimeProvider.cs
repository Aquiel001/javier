﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Models
{
    public class TimeProvider
    {
        public TimeProvider()
        {

        }
        public DateTime GetUtcNow() 
        {
           return DateTime.UtcNow;
        }
    }
}
