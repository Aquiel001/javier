﻿using Application.Common.Interfaces;
using Application.Common.Models;
using Domain.Entities.Messages;
using MimeKit.Text;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MailKit;
using PortalProcrea.Application.Common.Interfaces;
using Microsoft.EntityFrameworkCore.Internal;
using Microsoft.EntityFrameworkCore;

namespace Application.Common.Messages.Mail
{
    public class EmailSender : IEmailSender
    {
      
        public EmailSender()
        {
          
        }

        public virtual async Task SendEmailAsync(EmailAccount emailAccount, string subject, string body,
           string fromAddress, string fromName, string toAddress, string toName,
           string replyTo = null, string replyToName = null,
           IEnumerable<string> bcc = null, IEnumerable<string> cc = null,
           string attachmentFilePath = null, string attachmentFileName = null,
           int attachedDownloadId = 0, IDictionary<string, string> headers = null, 
           CancellationToken cancellationToken = default)
        {
            var message = new MimeMessage();

            message.From.Add(new MailboxAddress(fromName, fromAddress));
            message.To.Add(new MailboxAddress(toName, toAddress));

            if (!string.IsNullOrEmpty(replyTo))
            {
                message.ReplyTo.Add(new MailboxAddress(replyToName, replyTo));
            }

            //BCC
            if (bcc != null)
            {
                foreach (var address in bcc.Where(bccValue => !string.IsNullOrWhiteSpace(bccValue)))
                {
                    message.Bcc.Add(new MailboxAddress("", address.Trim()));
                }
            }

            //CC
            if (cc != null)
            {
                foreach (var address in cc.Where(ccValue => !string.IsNullOrWhiteSpace(ccValue)))
                {
                    message.Cc.Add(new MailboxAddress("", address.Trim()));
                }
            }

            //content
            message.Subject = subject;

            //headers
            if (headers != null)
                foreach (var header in headers)
                {
                    message.Headers.Add(header.Key, header.Value);
                }

            var multipart = new Multipart("mixed")
            {
                new TextPart(TextFormat.Html) { Text = body }
            };



            message.Body = multipart;


            var _smtpBuilder = new SmtpBuilder();

            //send email
            using var smtpClient = await _smtpBuilder.BuildAsync(emailAccount);

            //try
            //{
                await smtpClient.SendAsync(message);
                await smtpClient.DisconnectAsync(true);
            //}
            //catch (ServiceNotConnectedException)
            //{

            //    _context.EmailMessages.Add(new EmailMessage
            //    {
            //        EmailAccountId = emailAccount.Id,
            //        Subject = subject,
            //        Body = body,
            //        FromAddress = fromAddress,
            //        ToAddress = toAddress,
            //        FromName = fromName,
            //        ToName = toName,
            //        ReplyTo = replyTo,
            //        ReplyToName = replyToName,
            //        CC = cc is not null ? cc.ToString()! : "",
            //        BCC = bcc is not null ? bcc.ToString()! : ""
            //    });

            //    await _context.SaveChangesAsync(cancellationToken);

            //}
        }


        public virtual async Task SendEmailAsync(EmailAccount emailAccount, MessageTemplate template,
             string fromAddress, string fromName, string toAddress, string toName,
           string replyTo = null, string replyToName = null,
           IEnumerable<string> bcc = null, IEnumerable<string> cc = null,

          CancellationToken cancellationToken = default)
        {
            await SendEmailAsync(emailAccount, template.Subject, template.Body, fromAddress, fromName, toAddress, 
                                 toName, replyTo, replyToName, bcc, cc, null, null, 0, null, cancellationToken);
        }

        public virtual async Task SendEmailAsync(EmailMessage email,
            CancellationToken cancellationToken = default)
        {
            var bcc = email.BCC.Split(',').Select(x => x.Trim()).ToList();
            var cc = email.CC.Split(',').Select(x => x.Trim()).ToList();

            await SendEmailAsync(email.EmailAccount, email.Subject, email.Body, email.FromAddress, email.FromName, email.ToAddress,
                                 email.ToName, email.ReplyTo, email.ReplyToName, bcc, cc, email.AttachmentFilesPath, null,
                                 0, null, cancellationToken);
        }
    }

}
