﻿using Application.Common.Interfaces;
using Domain.Entities.Messages;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Common.Messages.Mail
{
    public class EmailQueue : IQueue<EmailMessage>
    {
        private readonly IApplicationDbContext _dbContext;
        private DbSet<EmailMessage> _emails => _dbContext.EmailMessages;

        public EmailQueue(IApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        
        public IReadOnlyCollection<EmailMessage> Emails 
        {
            get
            {
                return _emails.Include(x => x.EmailAccount).AsQueryable().ToList();
            }
        }

     
        public void Enqueue(EmailMessage message)
        {
             message.Id = 0;
            _emails.Add(message);
        }

        public EmailMessage? Dequeue()
        {
            EmailMessage? message = _emails.Include(x => x.EmailAccount).FirstOrDefault(x => x.FailAttemptsCount <= 5);
           
            if (message is not null) 
            {
                _emails.Remove(message);
            }

            return message;
          
        }

        public async Task SaveChangesAsync(CancellationToken cancellationToken =default) 
        {
            await _dbContext.SaveChangesAsync(cancellationToken);
        }
    }
}
