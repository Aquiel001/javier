﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Security
{
    public class UserDto
    {
        public string Id { get; set; } = default!;
        public string Name { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string UserName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public int? ProviderId { get; set; }
      //  public int ProviderName { get; set; } = default!;
    }

    public class RegisterDto : UserDto
    {
        public string Password { get; set; } = default!;
        public string ConfirmationPassword { get; set; } = default!;
    }
}

