﻿using Domain.Entities.Nomenclators;

namespace PortalProcrea.Application.Common.Interfaces;

public interface IUser
{
    string? Id { get; }
    Provider? Provider { get; }
}