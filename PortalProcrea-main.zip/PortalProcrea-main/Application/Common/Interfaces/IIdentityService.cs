﻿using Application.Common.Security;
using Domain.Entities.Nomenclators;
using PortalProcrea.Application.Common.Models;

namespace PortalProcrea.Common.Interfaces;

public interface IIdentityService
{
    Task<string?> GetUserNameAsync(string userId);
    Task<UserDto?> GetUserByIdAsync(string userId);
    Task<UserDto?> GetUserByUserNameAsync(string userName);

    UserDto? GetUserById(string userId);
    Provider? GetProviderByUserId(string userId);

    Task<bool> IsInRoleAsync(string userId, string role);

    Task<bool> AuthorizeAsync(string userId, string policyName);

    Task<(Result Result, string UserId)> CreateUserAsync(RegisterDto registerDto);
    Task<(Result Result, string UserId)> AddRolesAsync(string userId, string[] roles);
    Task<(Result Result, string UserId)> RemoveRolesAsync(string userId, string[] roles);

    Task<Result> DeleteUserAsync(string userId);

    Task<bool> CheckUserAndPassword(string username, string password);
    Task<PaginatedList<UserDto>> GetUsersWithPagination(int pageNumber = 1, int pageSize = 10);
    Task<IEnumerable<UserDto>> GetUsersByProviderAsync(int providerId);
    Task<IEnumerable<UserDto>> GetUsersByIdsAsync(IEnumerable<string> userIds);

}
