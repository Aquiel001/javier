﻿using Domain.Entities.Cart;
using Domain.Entities.Messages;
using Domain.Entities.Nomenclators;
using Domain.Entities.Offers;
using Domain.Entities.Orders;
using Domain.Entities.Requests;
using Domain.Entities.WishList;
using Microsoft.EntityFrameworkCore;

namespace PortalProcrea.Application.Common.Interfaces;

public interface IApplicationDbContext : IDisposable
{
    DbSet<Product> Products { get; }
    DbSet<Provider> Providers { get; }
    DbSet<Customer> Customers { get; }
    DbSet<Currency> Currencies { get; }
    DbSet<Country> Countries { get; }
    DbSet<Category> Categories { get; }
    DbSet<Service> Services { get; }
    DbSet<OrderRequest> OrderRequests { get; }
    DbSet<ShoppingCartItem> ShoppingCartItems { get; }
    DbSet<WishListItem> WishListItems { get; }
    DbSet<Offer> Offers { get; }
    DbSet<Order> Orders { get; }
    DbSet<EmailAccount> EmailAccounts { get; }
    DbSet<EmailMessage> EmailMessages { get; }
    DbSet<MessageTemplate> MessageTemplates { get; }

    Task<int> SaveChangesAsync(CancellationToken cancellationToken);
}
