﻿using Domain.Entities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Common.Interfaces
{
    public interface IQueue<TMessage>
    {
        void Enqueue(TMessage message);

        TMessage? Dequeue();

        IReadOnlyCollection<EmailMessage> Emails { get; }

        Task SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}
