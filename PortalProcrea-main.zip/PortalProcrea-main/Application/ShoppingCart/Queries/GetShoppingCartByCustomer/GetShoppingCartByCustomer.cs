﻿using Application.Common.Interfaces;
using Application.ShoppingCart.Dtos;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;

namespace Application.ShoppingCart.Queries.GetShoppingCartByCustomer
{
    public class GetShoppingCartByCustomerQuery : IRequest<PaginatedList<ShoppingCartItemDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
    }

    public class GetShoppingCartByCustomerQueryHandler : IRequestHandler<GetShoppingCartByCustomerQuery, PaginatedList<ShoppingCartItemDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMapper _mapper;
        private readonly IUser _user;
        private readonly IApplicationDbContextFactory _contextFactory;

        public GetShoppingCartByCustomerQueryHandler(IApplicationDbContext context, IMapper mapper, IUser user, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _user = user;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<ShoppingCartItemDto>> Handle(GetShoppingCartByCustomerQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.ShoppingCartItems
                  .Where(x => x.Customer!.UserId == _user.Id)
                  .OrderByDescending(x => x.Id)
                  .ProjectTo<ShoppingCartItemDto>(_mapper.ConfigurationProvider)
                  .PaginatedListAsync(request.PageNumber, request.PageSize);
            }

              
        }
    }
}
