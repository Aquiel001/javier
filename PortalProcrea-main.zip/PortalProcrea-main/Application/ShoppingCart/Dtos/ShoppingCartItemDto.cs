﻿using AutoMapper;
using Domain.Entities.Cart;
using Domain.Entities.Nomenclators;

namespace Application.ShoppingCart.Dtos
{
    public class ShoppingCartItemDto
    {
        public int Id { get; set; }
        public int? ProductId { get; set; }
        public string ProductName { get; set; } = string.Empty;
        public string ProductImagePath { get; set; } = string.Empty;
        public int? ServiceId { get; set; }
        public string ServiceName { get; set; } = string.Empty;
        public string ServiceImagePath { get; set; } = string.Empty;
        public decimal Quantity { get; set; }
        public int ProviderId { get; set; }
        public string ProviderName { get; set; } = string.Empty;

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<ShoppingCartItemDto, ShoppingCartItem>();
                CreateMap<ShoppingCartItem, ShoppingCartItemDto>()
                    .ForMember(dst => dst.ProductName, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.Name : ""))
                    .ForMember(dst => dst.ProductImagePath, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.ImagePath : "img/default-image.png"))
                    .ForMember(dst => dst.ServiceName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Name : ""))
                    .ForMember(dst => dst.ServiceImagePath, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.ImagePath : "img/default-image.png"))
                    .ForMember(dst => dst.ProviderId, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Provider!.Id : a.Product!.Provider!.Id))
                    .ForMember(dst => dst.ProviderName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Provider!.Name : a.Product!.Provider!.Name));
                    
            }
        }
    }
}
