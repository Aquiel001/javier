﻿using Application.ShoppingCart.Commands.AddItemsToShoppingCart;
using Application.ShoppingCart.Dtos;
using Domain.Entities.Cart;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ShoppingCart.Commands.RemoveElementsFromShoppingCart
{
    public class RemoveItemsFromShoppingCartCommand : IRequest<bool>
    {
        public List<int> ItemIds { get; set; } = new();
    }

    public class RemoveItemsFromShoppingCartCommandHandler : IRequestHandler<RemoveItemsFromShoppingCartCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public RemoveItemsFromShoppingCartCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(RemoveItemsFromShoppingCartCommand request, CancellationToken cancellationToken)
        {
            List<ShoppingCartItem> shoppingCartItems = _context.ShoppingCartItems
                                                               .Where(x => request.ItemIds.Contains(x.Id)).ToList();

           
             _context.ShoppingCartItems.RemoveRange(shoppingCartItems);

            return await _context.SaveChangesAsync(cancellationToken) == 1;
        }
    }
}
