﻿using Application.ShoppingCart.Commands.RemoveElementsFromShoppingCart;
using Domain.Entities.Cart;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ShoppingCart.Commands.RemoveItemsFromShoppingCart
{
    public class CleanShoppingCartCommand : IRequest
    {
        public string UserId { get; set; } = string.Empty;
    }

    public class CleanShoppingCartCommandHandler : IRequestHandler<CleanShoppingCartCommand>
    {
        private readonly IApplicationDbContext _context;

        public CleanShoppingCartCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task Handle(CleanShoppingCartCommand request, CancellationToken cancellationToken)
        {
            List<ShoppingCartItem> shoppingCartItems = _context.ShoppingCartItems
                                                               .Where(x => x.Customer.UserId.Equals(request.UserId)).ToList();


            _context.ShoppingCartItems.RemoveRange(shoppingCartItems);

            await _context.SaveChangesAsync(cancellationToken);
        }
    }
}
