﻿using Application.ShoppingCart.Dtos;
using Domain.Entities.Cart;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.ShoppingCart.Commands.AddItemsToShoppingCart
{
    public class UpdateShoppingCartCommand : IRequest
    {
        public List<ShoppingCartItemDto> Items { get; set; } = new();
    }

    public class UpdateShoppingCartCommandHandler : IRequestHandler<UpdateShoppingCartCommand>
    {
        private readonly IApplicationDbContext _context;
        private readonly IUser _user;

        public UpdateShoppingCartCommandHandler(IApplicationDbContext context, IUser user)
        {
            _context = context;
            _user = user;
        }

        public async Task Handle(UpdateShoppingCartCommand request, CancellationToken cancellationToken)
        {

            var customer = await _context.Customers.SingleOrDefaultAsync(x => x.UserId == _user.Id);
            if (customer is null)
                throw new Exception($"Customer not found.");

            var shoppingCart = _context.ShoppingCartItems
                                       .Where(x => x.CustomerId == customer.Id).ToList();
           
            List<ShoppingCartItem> newItems = new();
          
            if (shoppingCart is not null)
            {

                foreach (var item in request.Items)
                {
                    var oldItem = shoppingCart.FirstOrDefault(x => x.ProductId == item.ProductId || x.ServiceId == item.ServiceId);
                    if (oldItem is not null)
                    {
                        oldItem.Quantity = item.Quantity;
                        _context.ShoppingCartItems.Update(oldItem);
                    }
                    else 
                    {
                        var newItem = new ShoppingCartItem
                        {
                            CustomerId = customer.Id,
                            ProductId = item.ProductId,
                            ServiceId = item.ServiceId,
                            Quantity = item.Quantity
                        };

                        _context.ShoppingCartItems.Add(newItem);
                    }
                }
                
            }

            await _context.SaveChangesAsync(cancellationToken);


        }
    }

}
