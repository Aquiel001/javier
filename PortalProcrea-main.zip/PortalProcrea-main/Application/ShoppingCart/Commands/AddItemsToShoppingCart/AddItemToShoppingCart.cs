﻿using Application.Requests.Commands.CreateRequest;
using Application.Requests.Dtos;
using Application.ShoppingCart.Dtos;
using Domain.Entities.Cart;
using Domain.Entities.Requests;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Application.ShoppingCart.Commands.AddItemsToShoppingCart
{
    public class AddItemToShoppingCartCommand : IRequest
    {
        public ShoppingCartItemDto Item { get; set; } = new();
    }

    public class AddItemToShoppingCartCommandHandler : IRequestHandler<AddItemToShoppingCartCommand>
    {
        private readonly IApplicationDbContext _context;
        private readonly IUser _user;

        public AddItemToShoppingCartCommandHandler(IApplicationDbContext context, IUser user)
        {
            _context = context;
            _user = user;
        }

        public async Task Handle(AddItemToShoppingCartCommand request, CancellationToken cancellationToken)
        {
            
            var customer = await _context.Customers.SingleOrDefaultAsync(x => x.UserId == _user.Id);
            if (customer is null)
                throw new Exception($"Customer not found.");

           var shoppingCart = _context.ShoppingCartItems
                                      .FirstOrDefault(x => x.CustomerId == customer.Id &&
                                      ((x.ProductId > 0 && x.ProductId == request.Item.ProductId) ||
                                      (x.ServiceId > 0 && x.ServiceId == request.Item.ServiceId)));

            if (shoppingCart is null)
            {
                var shoppingCartItem = new ShoppingCartItem
                {
                    CustomerId = customer.Id,
                    ProductId = request.Item.ProductId,
                    ServiceId = request.Item.ServiceId,
                    Quantity = request.Item.Quantity

                };

                _context.ShoppingCartItems.Add(shoppingCartItem);
            }

            else 
            {
                shoppingCart.Quantity+= request.Item.Quantity;
                _context.ShoppingCartItems.Update(shoppingCart);
            }
                
             await _context.SaveChangesAsync(cancellationToken);


        }
    }

}
