﻿using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Orders.Commands.AceptOrder
{
    public class AceptOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }

    }

    public class AceptOrderCommandHandler : IRequestHandler<AceptOrderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public AceptOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AceptOrderCommand request, CancellationToken cancellationToken)
        {

            var order = await _context.Orders.Include(x => x.Provider)
                                             .FirstAsync(x => x.Id == request.OrderId);

            if (order is null)
                throw new Exception("Order not found.");

            order.OrderStatus = Domain.Enums.OrderStatus.Processing;

            //adding domain event AceptedOrderEvent
            order.AddDomainEvent(new AceptedOrderEvent(order));

            _context.Orders.Update(order);

           return await _context.SaveChangesAsync(cancellationToken) == 1;


        }
    }
}
