﻿using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Orders.Commands.AddDocumentToOrder
{
    public class AddDocumentToOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }
        public string DocumentPath { get; set; } = string.Empty;
    }

    public class AddDocumentToOrderCommandHandler : IRequestHandler<AddDocumentToOrderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public AddDocumentToOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AddDocumentToOrderCommand request, CancellationToken cancellationToken)
        {
            var order = await _context.Orders.FindAsync(request.OrderId);

            if (order is null)
                throw new Exception("Order not found.");

            order.Document = request.DocumentPath;

            _context.Orders.Update(order);

            return await _context.SaveChangesAsync(cancellationToken) == 1;
        }
    }
}
