﻿using Application.Offers.Events;
using Domain.Entities.Orders;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Orders.Commands.CreateOrder
{
    public class CreateOrderCommand : IRequest<int>
    {
        public int OfferId { get; set; }
       
    }

    public class CreateOrderCommandHandler : IRequestHandler<CreateOrderCommand, int>
    {
        private readonly IApplicationDbContext _context;
        private readonly IMediator _mediator;

        public CreateOrderCommandHandler(IApplicationDbContext context, IMediator mediator)
        {
            _context = context;
            _mediator = mediator;
        }

        public async Task<int> Handle(CreateOrderCommand request, CancellationToken cancellationToken)
        {

            var offer = await _context.Offers.FindAsync(request.OfferId);

            if (offer is null)
                throw new Exception("Offer not found.");
            
                var order = new Order
                {
                    CustomerId = offer.OrderRequest.CustomerId,
                    OrderStatus = Domain.Enums.OrderStatus.Pending,
                    Items = offer.Items.Select(item => new OrderItem
                    {
                        ProductId = item.ProductId,
                        ServiceId = item.ServiceId,
                        Quantity = item.Quantity,
                        UnitPrice = item.UnitPrice,
                        TotalPrice = item.TotalPrice
                    }).ToList()
                };

            order.PaymentAmount = (int)order.Items.Sum(x => x.TotalPrice);


            //adding a domain event CreatedOrderEvent
            order.AddDomainEvent(new CreatedOrderEvent(order));
          
            _context.Orders.Add(order);

                 offer.Accepted = true;
                _context.Offers.Update(offer);

                await _context.SaveChangesAsync(cancellationToken);

            //publishing event RejectedOffersEvent
            var rejectedOffers = await _context.Offers
                            .Where(x => x.OrderRequestId == offer.OrderRequestId &&
                            !x.Accepted.HasValue).ToListAsync();

            if (rejectedOffers.Any()) 
            {
                await _mediator.Publish(new RejectedOffersEvent(rejectedOffers));
            }

            var orderRequest = await _context.OrderRequests.FindAsync(offer.OrderRequestId);

            if (orderRequest != null)
            {
                orderRequest.OrderRequestStatusId = 40;

                _context.OrderRequests.Update(orderRequest);

                await _context.SaveChangesAsync(cancellationToken);
            }
           
            return order.Id;

        }
    }
}
