﻿using Application.Orders.Commands.AddPaymentsToOrder;
using Domain.Enums;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.Commands.AddPaymentTypeToOrder
{
    public class AddPaymentTypeToOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }
        public string PaymentType { get; set; } = string.Empty;

    }

    public class AddPaymentTypeToOrderCommandHandler : IRequestHandler<AddPaymentTypeToOrderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public AddPaymentTypeToOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AddPaymentTypeToOrderCommand request, CancellationToken cancellationToken)
        {
            var order = await _context.Orders.FindAsync(request.OrderId);

            if (order is null)
                throw new Exception("Order not found.");

            if (request.PaymentType == "Single")
            {
                order.PaymentType = Domain.Enums.PaymentType.Single;
            }
            else
            {
                order.PaymentType = Domain.Enums.PaymentType.Multiple;
            }


            _context.Orders.Update(order);

            return await _context.SaveChangesAsync(cancellationToken) == 1;
        }
    }
}
