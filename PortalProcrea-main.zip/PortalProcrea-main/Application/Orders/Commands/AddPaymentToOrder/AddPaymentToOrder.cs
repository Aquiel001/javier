﻿using Application.Orders.Commands.AddAllowedCurrenciesToOrder;
using MediatR;
using PortalProcrea.Application.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.Commands.AddPaymentsToOrder
{
    public class AddPaymentToOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }
        public string NoTransaction { get; set; } = string.Empty;
        public decimal Amount { get; set; }
        public int PaymentMethodId { get; set; }

    }

    public class AddPaymentToOrderCommandHandler : IRequestHandler<AddPaymentToOrderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public AddPaymentToOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AddPaymentToOrderCommand request, CancellationToken cancellationToken)
        {

            var order = await _context.Orders.FindAsync(request.OrderId);

            if (order is null)
                throw new Exception("Order not found.");

            order.AddPayment(new Domain.Entities.Orders.OrderPayment 
            { 
                NoTransaction = request.NoTransaction, 
                Amount = request.Amount, 
                PaymentMethodId = request.PaymentMethodId
            });

            _context.Orders.Update(order);

            return await _context.SaveChangesAsync(cancellationToken) == 1;


        }
    }
}
