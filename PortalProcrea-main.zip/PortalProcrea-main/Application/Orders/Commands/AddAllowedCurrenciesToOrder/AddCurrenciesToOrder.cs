﻿using MediatR;
using PortalProcrea.Application.Common.Interfaces;

namespace Application.Orders.Commands.AddAllowedCurrenciesToOrder
{
    public class AddCurrenciesToOrderCommand : IRequest<bool>
    {
        public int OrderId { get; set; }
        public List<int> CurrencyIds { get; set; } = new();

    }

    public class AddCurrenciesToOrderCommandHandler : IRequestHandler<AddCurrenciesToOrderCommand, bool>
    {
        private readonly IApplicationDbContext _context;

        public AddCurrenciesToOrderCommandHandler(IApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<bool> Handle(AddCurrenciesToOrderCommand request, CancellationToken cancellationToken)
        {

            var order = await _context.Orders.FindAsync(request.OrderId);

            if (order is null)
                throw new Exception("Order not found.");

            var currencies = _context.Currencies.Where(c => request.CurrencyIds.Contains(c.Id)).ToList();
            if (!currencies.Any())
                throw new Exception("No currencies founded.");

            order.AddCurrencyList(currencies);

            _context.Orders.Update(order);

           return await _context.SaveChangesAsync(cancellationToken) == 1;


        }
    }
}
