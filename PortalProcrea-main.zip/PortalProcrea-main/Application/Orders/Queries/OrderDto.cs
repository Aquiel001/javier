﻿using Application.Orders.Dtos;
using AutoMapper;
using Domain.Entities.Nomenclators;
using Domain.Entities.Orders;

namespace Application.Orders.Queries
{
    public class OrderDto
    {
        public int Id { get; set; }
        public string Code { get; set; } = default!;
        public string CustomerName { get; set; } = default!;
        public string CustomerLastName { get; set; } = default!;
        public int OrderStatusId { get; set; }
        public int Amount { get; set; }
        public bool Accepted { get; set; }
        public DateTimeOffset Created { get; set; }
        public string? CreatedBy { get; set; }
        public List<OrderItemDto> Items { get; set; } = new();
        public List<OrderCurrency> AllowedCurrencies { get; set; } = new();
        public string PaymentType { get; set; } = default!;
        public List<OrderPayment> Payments { get; set; } = new();
        public string SelectedCurrencyClient { get; set; } = default!;

        private class Mapping : Profile
        {
            public Mapping()
            {
                CreateMap<Order, OrderDto>()
                    .ForMember(dst => dst.CustomerName, src => src.MapFrom(a => a.Customer.Name.ToUpper()))
                    .ForMember(dst => dst.CustomerLastName, src => src.MapFrom(a => a.Customer.LastName.ToUpper()))
                    .ForMember(dst => dst.PaymentType, src => src.MapFrom(a => a.PaymentType))
                    .ForMember(dst => dst.Amount, src => src.MapFrom(a => a.PaymentAmount))
                    .ForMember(dst => dst.SelectedCurrencyClient, src => src.MapFrom(a => a.Currency.Name));
                CreateMap<OrderItem, OrderItemDto>()
                    .ForMember(dst => dst.ProductName, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.Name : ""))
                    .ForMember(dst => dst.ProductImagePath, src => src.MapFrom(a => a.Product != default(Product) ? a.Product.ImagePath : ""))
                    .ForMember(dst => dst.ServiceName, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.Name : ""))
                    .ForMember(dst => dst.ServiceImagePath, src => src.MapFrom(a => a.Service != default(Service) ? a.Service.ImagePath : ""));
                ;
            }
        }
    }
}
