﻿using Application.Common.Interfaces;
using Application.Orders.Queries;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Application.Common.Mappings;
using PortalProcrea.Application.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.Queries
{
    public class GetOrdersByProviderWithPaginationQuery : IRequest<PaginatedList<OrderDto>>
    {
        public int PageNumber { get; init; } = 1;
        public int PageSize { get; init; } = 10;
        public int ProviderId { get; init; }
    }

    public class GetOrdersByProviderWithPaginationQueryHandler : IRequestHandler<GetOrdersByProviderWithPaginationQuery, PaginatedList<OrderDto>>
    {
        private readonly IApplicationDbContext _context;
        private readonly IApplicationDbContextFactory _contextFactory;
        private readonly IMapper _mapper;

        public GetOrdersByProviderWithPaginationQueryHandler(IApplicationDbContext context, IMapper mapper, IApplicationDbContextFactory contextFactory)
        {
            _context = context;
            _mapper = mapper;
            _contextFactory = contextFactory;
        }

        public async Task<PaginatedList<OrderDto>> Handle(GetOrdersByProviderWithPaginationQuery request, CancellationToken cancellationToken)
        {
            using (var context = _contextFactory.CreateDbContext())
            {
                return await context.Orders
                        .Where(l => l.Provider != null && l.Provider.Id == request.ProviderId)
                        .Include(l => l.Provider)
                        .OrderByDescending(x => x.Id)
                        .ProjectTo<OrderDto>(_mapper.ConfigurationProvider)
                        .PaginatedListAsync(request.PageNumber, request.PageSize);
            }
        }
    }
}