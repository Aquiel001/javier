﻿using Application.Common.Interfaces;
using Application.Common.Security;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;

namespace Application.Orders.EventHandlers
{
    public class CanceledOrderEventHandler : INotificationHandler<CanceledOrderEvent>
    {
        private readonly ILogger<CanceledOrderEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public CanceledOrderEventHandler(ILogger<CanceledOrderEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(CanceledOrderEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after the order was canceled.");

            //var template = await _mediator.Send(new GetMessageTemplateByNameQuery
            //{
            //    Name = MessageTemplateSystemNames.NewOrderMessage
            //});

            var providerId = notification.Order.Provider!.Id;

            var users = await _identityService.GetUsersByProviderAsync(providerId);

            List<UserDto> admins = new();

            foreach (var user in users)
            {
                bool isAdmin = await _identityService.IsInRoleAsync(user.Id, Roles.Administrator);
                if (isAdmin)
                {
                    admins.Add(user);
                }
            }

            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();

            foreach (var admin in admins)
            {
                _queue.Enqueue(new EmailMessage
                {
                    EmailAccount = eamailAccount,
                    FromAddress = eamailAccount.Username,
                    FromName = eamailAccount.DisplayName,
                    ToAddress = admin!.Email,
                    ToName = admin.Name,
                    //Subject = template!.Subject,
                    //Body = template.Body, 
                    Subject = "Order was canceled",
                    Body = $"Order {notification.Order.Code} was canceled {Environment.NewLine} Cause: {notification.Observations}"

                });
            }

            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}
