﻿using Application.Common.Interfaces;
using Application.Common.Security;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.EventHandlers
{
    public class CompletedOrderEventHandler : INotificationHandler<CompletedOrderEvent>
    {
        private readonly ILogger<CompletedOrderEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public CompletedOrderEventHandler(ILogger<CompletedOrderEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(CompletedOrderEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after the offer was accepted.");

            //var template = await _mediator.Send(new GetMessageTemplateByNameQuery
            //{
            //    Name = MessageTemplateSystemNames.NewOrderMessage
            //});

            var customer = notification.Order.Customer;

            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();

            _queue.Enqueue(new EmailMessage
            {
                EmailAccount = eamailAccount,
                FromAddress = eamailAccount.Username,
                FromName = eamailAccount.DisplayName,
                ToAddress = customer!.Email,
                ToName = customer.Name,
                //Subject = template!.Subject,
                //Body = template.Body, 
                Subject = "Order was completed",
                Body = $"Order {notification.Order.Code} was completed"

            });

            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}
