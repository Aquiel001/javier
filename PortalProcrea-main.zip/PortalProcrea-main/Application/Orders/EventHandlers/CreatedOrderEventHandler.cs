﻿using Application.Common.Interfaces;
using Application.MessageTemplates.Queries;
using Application.Orders.EventHandlers;
using Domain.Constants;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.EventHandlers
{
    public class CreatedOrderEventHandler : INotificationHandler<CreatedOrderEvent>
    {
        private readonly ILogger<CreatedOrderEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public CreatedOrderEventHandler(ILogger<CreatedOrderEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(CreatedOrderEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after the order was created.");

            var template = await _mediator.Send(new GetMessageTemplateByNameQuery
            {
                Name = MessageTemplateSystemNames.NewOrderMessage
            });

            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();

            var customer = await _dbContext.Customers.FirstAsync(x => x.Id == notification.Order.CustomerId);

            _queue.Enqueue(new EmailMessage
            {
                EmailAccount = eamailAccount,
                FromAddress = eamailAccount.Username,
                FromName = eamailAccount.DisplayName,
                ToAddress = customer.Email,
                ToName = customer.Name,
                Subject = template!.Subject,
                Body = template.Body,

            });

            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}