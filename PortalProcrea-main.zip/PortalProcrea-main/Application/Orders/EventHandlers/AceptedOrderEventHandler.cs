﻿using Application.Common.Interfaces;
using Application.Common.Security;
using Application.MessageTemplates.Queries;
using Application.Offers.EventHandlers;
using Domain.Constants;
using Domain.Entities.Messages;
using Domain.Events;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PortalProcrea.Application.Common.Interfaces;
using PortalProcrea.Common.Interfaces;
using PortalProcrea.Domain.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Orders.EventHandlers
{
    public class AceptedOrderEventHandler : INotificationHandler<AceptedOrderEvent>
    {
        private readonly ILogger<AceptedOrderEventHandler> _logger;
        private readonly IMediator _mediator;
        private readonly IIdentityService _identityService;
        private readonly IApplicationDbContext _dbContext;
        private readonly IQueue<EmailMessage> _queue;

        public AceptedOrderEventHandler(ILogger<AceptedOrderEventHandler> logger, IMediator mediator, IIdentityService identityService, IApplicationDbContext dbContext, IQueue<EmailMessage> queue)
        {
            _logger = logger;
            _mediator = mediator;
            _identityService = identityService;
            _dbContext = dbContext;
            _queue = queue;
        }

        public async Task Handle(AceptedOrderEvent notification, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Sending emails after the offer was accepted.");

            //var template = await _mediator.Send(new GetMessageTemplateByNameQuery
            //{
            //    Name = MessageTemplateSystemNames.NewOrderMessage
            //});

            var providerId = notification.Order.Provider!.Id;

            var users = await _identityService.GetUsersByProviderAsync(providerId);

            List<UserDto> admins = new();

            foreach (var user in users)
            {
                bool isAdmin = await _identityService.IsInRoleAsync(user.Id, Roles.Administrator);
                if (isAdmin)
                {
                    admins.Add(user);
                }
            }

            var eamailAccount = await _dbContext.EmailAccounts.FirstAsync();

            foreach (var admin in admins)
            {
                _queue.Enqueue(new EmailMessage
                {
                    EmailAccount = eamailAccount,
                    FromAddress = eamailAccount.Username,
                    FromName = eamailAccount.DisplayName,
                    ToAddress = admin!.Email,
                    ToName = admin.Name,
                    //Subject = template!.Subject,
                    //Body = template.Body, 
                    Subject = "Order was acepted",
                    Body = $"Order {notification.Order.Code} was acepted"

                });
            }

            await _queue.SaveChangesAsync(cancellationToken);
        }
    }
}
