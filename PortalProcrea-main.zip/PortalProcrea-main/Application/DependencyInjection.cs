﻿using Application.Common.Interfaces;
using Application.Common.Messages.Mail;
using Application.Common.Models;
using Application.ScheudleTasks.BackgroundServices;
using Domain.Entities.Messages;
using FluentValidation;
using MediatR;
using PortalProcrea.Application.Common.Behaviours;
using System.Reflection;

namespace Microsoft.Extensions.DependencyInjection;

public static class DependencyInjection
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        //add mediator services
        services.AddSingleton(new TimeProvider());
        services.AddScoped<ISmtpBuilder, SmtpBuilder>();
        services.AddScoped<IEmailSender, EmailSender>();
        services.AddScoped<IQueue<EmailMessage>, EmailQueue>();

        services.AddAutoMapper(Assembly.GetExecutingAssembly());

        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());

        services.AddMediatR(cfg => {
            cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(UnhandledExceptionBehaviour<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(AuthorizationBehaviour<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(PerformanceBehaviour<,>));
        });

        //background services
        services.AddHostedService<EmailSenderBackgroundService>();

        return services;
    }
}