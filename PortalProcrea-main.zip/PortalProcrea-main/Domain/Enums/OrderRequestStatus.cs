﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum OrderRequestStatus
    {
        /// <summary>
        /// Pending
        /// </summary>
        Pending = 10,

        /// <summary>
        /// Accepted
        /// </summary>
        Accepted = 20,

        /// <summary>
        /// Denied
        /// </summary>
        Denied = 30,

        /// <summary>
        /// Complete
        /// </summary>
        Complete = 40,
    }
}
