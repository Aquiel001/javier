﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Enums
{
    public enum PaymentType
    {
        /// <summary>
        /// Single Payment
        /// </summary>
        Single,
       
        /// <summary>
        /// Multiple Payments
        /// </summary>
        Multiple

    }
}
