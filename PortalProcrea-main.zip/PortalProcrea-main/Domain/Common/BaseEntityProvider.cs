﻿using Domain.Entities.Nomenclators;
using Domain.Interfaces;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Common
{
    public class BaseEntityProvider : BaseEntity, IProvider
    {
        //[ForeignKey("ProviderId")]
        //public virtual int ProviderId { get; set; }
        public virtual Provider? Provider { get; set; } = default!;
    }
}
