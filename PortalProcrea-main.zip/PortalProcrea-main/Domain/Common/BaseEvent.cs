﻿using MediatR;

namespace PortalProcrea.Domain.Common;

public abstract class BaseEvent : INotification
{
}
