﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Constants
{
    public abstract class MessageTemplateSystemNames
    {
        /// <summary>
        /// Represents system name of notification about new registration
        /// </summary>
        public const string CustomerRegisteredNotification = "NewCustomer.Notification";

        /// <summary>
        /// Represents system name of customer welcome message
        /// </summary>
        public const string CustomerWelcomeMessage = "Customer.WelcomeMessage";

        /// <summary>
        /// Represents system name of notification about new order request
        /// </summary>
        public const string NewOrderRequestMessage = "OrderRequest.NewOrderRequestMessage";

        /// <summary>
        /// Represents system name of notification about new offer posted
        /// </summary>
        public const string NewOfferMessage = "Offers.NewOfferMessage";

        /// <summary>
        /// Represents system name of notification about rejected offer
        /// </summary>
        public const string RejectOfferMessage = "Offers.RejectOfferMessage";

        /// <summary>
        /// Represents system name of notification about new order created
        /// </summary>
        public const string NewOrderMessage = "Forums.NewOrderMessage";
    }
}
