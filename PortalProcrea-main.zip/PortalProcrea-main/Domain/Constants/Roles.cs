﻿namespace PortalProcrea.Domain.Constants;
public abstract class Roles
{
    public const string SuperAdministrator = nameof(SuperAdministrator);
    public const string Administrator = nameof(Administrator);
    public const string Comercial = nameof(Comercial);
    public const string Marketing = nameof(Marketing);
}
