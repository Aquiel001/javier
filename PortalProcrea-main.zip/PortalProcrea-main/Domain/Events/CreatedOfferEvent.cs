﻿using Domain.Entities.Offers;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Events
{
    public class CreatedOfferEvent : BaseEvent
    {
        public CreatedOfferEvent(Offer offer)
        {
            Offer = offer;
        }

        public Offer Offer { get; }
    }
}