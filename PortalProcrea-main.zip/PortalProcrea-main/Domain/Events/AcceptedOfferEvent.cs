﻿using Domain.Entities.Offers;
using PortalProcrea.Domain.Common;

namespace Domain.Events
{
    public class AcceptedOfferEvent : BaseEvent
    {
        public AcceptedOfferEvent(Offer offer)
        {
            Offer = offer;
        }

        public Offer Offer { get; }
    }
}