﻿using Domain.Entities.Orders;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Events
{
    public class CanceledOrderEvent : BaseEvent
    {
        public CanceledOrderEvent(Order order, string observations)
        {
            Order = order;
            Observations = observations;
        }

        public Order Order { get; }
        public string Observations { get; }
    }
}