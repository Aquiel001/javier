﻿using Domain.Entities.Nomenclators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Interfaces
{
    public interface IProvider
    {
      //  int ProviderId { get; set; }
        Provider? Provider { get; set; }
    }
}
