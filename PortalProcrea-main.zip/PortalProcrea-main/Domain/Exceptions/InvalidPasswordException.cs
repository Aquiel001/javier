﻿namespace PortalProcrea.Domain.Exceptions;
public class InvalidPasswordException : Exception
{
    public InvalidPasswordException()
       : base($"The password must contains most than 6 characters and incluide min and may.")
    {
    }
}
