﻿using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Nomenclators
{
    public class Customer : BaseEntity
    {
        public string UserId { get; private set; } = string.Empty;
        public string Name { get; private set; } = string.Empty;
        public string LastName { get; private set; } = string.Empty;
        public string Email { get; private set; } = default!;
        public bool IsCompany { get; set; }
        public string CodeNit { get; set; } = string.Empty;
        public string BankAccount { get; set; } = string.Empty;

        [ForeignKey("CountryId")]
        public int CountryId { get; set; }
        public virtual Country Country { get; set; } = default!;

        [ForeignKey("CurrentCurrencyId")]
        public int CurrentCurrencyId { get; set; }
        public virtual Currency CurrentCurrency { get; set; } = default!;

        public Customer(string userId, string name, string lastName, string email)
        {
            UserId = userId;
            Name = name;
            LastName = lastName;
            Email = email;
          
        }
    }
}
