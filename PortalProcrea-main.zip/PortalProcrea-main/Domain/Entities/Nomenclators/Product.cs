﻿using Domain.Common;
using Domain.Events;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Nomenclators
{
    public class Product : BaseEntityProvider
    {
        public string Name { get; set; } = default!;
        public string Code { get; set; } = default!;
        
        private bool _new;
        public bool New
        {
            get => _new;
            set
            {
                if (value && !_new)
                {
                    AddDomainEvent(new ProductNewEvent(this));
                }

                _new = value;
            }
        }
        public string ImagePath { get; set; } = "default-image.png";
        public bool ShowInMainView { get; set; }
        public bool Published { get; set; }
        public double Rating { get; set; }
        public bool Active { get; set; }
    }
}
