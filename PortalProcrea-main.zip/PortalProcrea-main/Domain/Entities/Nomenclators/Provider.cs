﻿using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Nomenclators
{
    public class Provider : BaseEntity
    {
        public string Name { get; set; } = default!;
        public string Code { get; set; } = default!;
        public string LogoPath { get; set; } = "default-image.png";
        public bool Active { get; set; }
    }
}
