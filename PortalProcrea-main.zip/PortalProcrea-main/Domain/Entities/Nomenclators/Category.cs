﻿using Domain.Common;
using Domain.Interfaces;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Nomenclators
{
    public class Category : BaseEntityProvider
    {
        public string Name { get; set; } = default!;
        public bool Active { get; set; }
    }
}
