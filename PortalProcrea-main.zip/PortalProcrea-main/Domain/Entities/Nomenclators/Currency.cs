﻿using PortalProcrea.Domain.Common;

namespace Domain.Entities.Nomenclators
{
    public class Currency : BaseEntity
    {
        public string Name { get; set; } = string.Empty;
        public string CurrencyCode { get; set; } = string.Empty;
        public double Rate { get; set; }
        public bool Active { get; set; }
    }
}
