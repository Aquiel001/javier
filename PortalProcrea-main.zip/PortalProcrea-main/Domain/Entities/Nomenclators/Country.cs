﻿using PortalProcrea.Domain.Common;

namespace Domain.Entities.Nomenclators
{
    public class Country : BaseEntity
    {
        public string Name { get; set; } = default!;
        public string ShortName { get; set; } = default!;
        public bool Active { get; set; }
    }
}
