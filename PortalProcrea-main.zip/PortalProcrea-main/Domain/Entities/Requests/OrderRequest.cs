﻿using Domain.Entities.Nomenclators;
using Domain.Enums;
using Domain.Events;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Requests
{
    public class OrderRequest : BaseEntity
    {

        //public OrderRequest()
        //{
        //    AddDomainEvent(new CreatedOrderRequestEvent(this));
        //}


        [ForeignKey("CustomerId")]
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; } = default!;
       
        public int OrderRequestStatusId { get; set; }
        public OrderRequestStatus OrderStatus
        {
            get => (OrderRequestStatus)OrderRequestStatusId;
            set => OrderRequestStatusId = (int)value;
        }

        [ForeignKey("ProviderId")]
        public int ProviderId { get; set; }
        public virtual Provider Provider { get; set; } = default!;

        public virtual IList<OrderRequestItem> Items { get; set; } = new List<OrderRequestItem>();


        #region Methods

        public void AddOrderRequest(OrderRequestItem item) 
        {
            item.OrderRequest = this;
            Items.Add(item);
        }

        public void AddOrderRequestList(IEnumerable<OrderRequestItem> items)
        {
            if (items.Count() > 0) 
            {
                foreach (var item in items)
                {
                    AddOrderRequest(item);
                }
               
            }
        }

        #endregion
    }
}
