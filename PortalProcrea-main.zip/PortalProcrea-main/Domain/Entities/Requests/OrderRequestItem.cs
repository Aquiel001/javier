﻿using Domain.Entities.Nomenclators;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Requests
{
    public class OrderRequestItem : BaseEntity
    {
        public decimal Quantity { get; set; }

        [ForeignKey("OrderRequestId")]
        public int OrderRequestId { get; set; }
        public virtual OrderRequest OrderRequest { get; set; } = default!;

        [ForeignKey("ProductId")]
        public int? ProductId { get; set; }
        public virtual Product? Product { get; set; }

        [ForeignKey("ServiceId")]
        public int? ServiceId { get; set; }
        public virtual Service? Service { get; set; }

    }
}
