﻿using Domain.Entities.Nomenclators;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Messages
{
    public class EmailMessage : BaseEntity
    {
        public string Subject { get; set; } = string.Empty;
        public string Body { get; set; } = string.Empty;
        public string FromAddress { get; set; } = string.Empty;
        public string FromName { get; set; } = string.Empty;
        public string ToAddress { get; set; } = string.Empty;
        public string ToName { get; set; } = string.Empty;
        public string ReplyTo { get; set; } = string.Empty;
        public string ReplyToName { get; set; } = string.Empty;
        public string BCC { get; set; } = string.Empty;
        public string CC { get; set; } = string.Empty;
        public string AttachmentFilesPath { get; set; } = string.Empty;
        public int FailAttemptsCount { get; set; }

        [ForeignKey("EmailAccountId")]
        public int EmailAccountId { get; set; }
        public virtual EmailAccount EmailAccount { get; set; } = default!;

    }
}
