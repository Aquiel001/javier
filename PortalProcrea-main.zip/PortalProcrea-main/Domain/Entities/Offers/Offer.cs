﻿using Domain.Common;
using Domain.Entities.Nomenclators;
using Domain.Entities.Requests;
using Domain.Events;
using PortalProcrea.Domain.Common;
using PortalProcrea.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Offers
{
    public class Offer : BaseEntityProvider, IAuditableEntity
    {
        //public Offer()
        //{
        //    AddDomainEvent(new CreatedOfferEvent(this));
        //}

        [ForeignKey("OrderRequestId")]
        public int OrderRequestId { get; set; }
        public virtual OrderRequest OrderRequest { get; set; } = default!;

        //whether or not this offer was accepted to convert in order
        public bool? Accepted { get; set; }

        public DateTimeOffset Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset LastModified { get; set; }
        public string? LastModifiedBy { get; set; }

        public virtual IList<OfferItem> Items { get; set; } = new List<OfferItem>();


        #region Methods

        public void AddOffer(OfferItem item)
        {
            item.Offer = this;
            Items.Add(item);
        }

        public void AddOfferList(IEnumerable<OfferItem> items)
        {
            if (items.Count() > 0)
            {
                foreach (var item in items)
                {
                    AddOffer(item);
                }

            }
        }

        #endregion


    }
}
