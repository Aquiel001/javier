﻿using Domain.Common;
using Domain.Entities.Nomenclators;
using Domain.Entities.Requests;
using PortalProcrea.Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Offers
{
    public class OfferItem : BaseEntityProvider
    {
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal TotalPrice { get; set; }

        [ForeignKey("OfferId")]
        public int OfferId { get; set; }
        public virtual Offer Offer { get; set; } = default!;

        [ForeignKey("ProductId")]
        public int? ProductId { get; set; }
        public virtual Product? Product { get; set; }

        [ForeignKey("ServiceId")]
        public int? ServiceId { get; set; }
        public virtual Service? Service { get; set; }

    }
}
