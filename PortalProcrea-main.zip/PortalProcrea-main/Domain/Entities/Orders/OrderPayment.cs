﻿using Domain.Common;
using Domain.Enums;
using PortalProcrea.Domain.Common;
using PortalProcrea.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Orders
{
    public class OrderPayment : BaseEntityProvider, IAuditableEntity
    {
        [ForeignKey("OrderId")]
        public int OrderId { get; set; }
        public virtual Order Order { get; set; } = default!;

        public string NoTransaction { get; set; } = string.Empty;

        public decimal Amount { get; set; }
        
        public int PaymentMethodId { get; set; }
        public PaymentMethod PaymentMethod
        {
            get => (PaymentMethod)PaymentMethodId;
            set => PaymentMethodId = (int)value;
        }
        
        public DateTimeOffset Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset LastModified { get; set; }
        public string? LastModifiedBy { get; set; }
    }
}
