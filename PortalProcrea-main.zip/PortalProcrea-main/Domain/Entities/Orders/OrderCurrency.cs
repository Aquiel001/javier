﻿using Domain.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Entities.Orders
{
    public class OrderCurrency : BaseEntityProvider
    {
        [ForeignKey("OrderId")]
        public int OrderId { get; set; }
        public virtual Order Order { get; set; } = default!;

        public string CurrencyCode { get; set; } = string.Empty;
        public decimal CurrencyRate { get; set; }
    }
}
