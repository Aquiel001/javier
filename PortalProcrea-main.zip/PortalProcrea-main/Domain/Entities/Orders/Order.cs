﻿using Domain.Common;
using Domain.Entities.Nomenclators;
using Domain.Enums;
using PortalProcrea.Domain.Interfaces;
using System.ComponentModel.DataAnnotations.Schema;

namespace Domain.Entities.Orders
{
    public class Order : BaseEntityProvider, IAuditableEntity
    {

        //public Order()
        //{
        //    AddDomainEvent(new CreatedOrderEvent(this));
        //}

        public string Code { get; set; } = string.Empty;

        public int OrderStatusId { get; set; }
        public OrderStatus OrderStatus
        {
            get => (OrderStatus)OrderStatusId;
            set => OrderStatusId = (int)value;
        }

        public int PaymentTypeId { get; set; }
        public PaymentType PaymentType
        {
            get => (PaymentType)PaymentTypeId;
            set => PaymentTypeId = (int)value;
        }
        public int PaymentAmount { get; set; }

        [ForeignKey("CustomerId")]
        public int CustomerId { get; set; }
        public virtual Customer Customer { get; set; } = default!;

        [ForeignKey("CurrencyId")]
        public int CurrencyId { get; set; }
        public virtual Currency Currency { get; set; } = default!;
        public string Document { get; set; } = string.Empty;
        public DateTimeOffset Created { get; set; }
        public string? CreatedBy { get; set; }
        public DateTimeOffset LastModified { get; set; }
        public string? LastModifiedBy { get; set; }

        public virtual IList<OrderCurrency> AllowedCurrencies { get; set; } = new List<OrderCurrency>();
        public virtual IList<OrderItem> Items { get; set; } = new List<OrderItem>();
        public virtual IList<OrderPayment> Payments { get; set; } = new List<OrderPayment>();

        #region Methods

        #region Order Items

        public void AddProduct(OrderItem item)
        {
            item.Order = this;
            Items.Add(item);
        }

        public void AddProductList(IEnumerable<OrderItem> items)
        {
            if (items.Count() > 0)
            {
                foreach (var item in items)
                {
                    AddProduct(item);
                }

            }
        }

        #endregion

        #region Order Currencies

        public void AddCurrency(OrderCurrency currency)
        {
            currency.Order = this;
            AllowedCurrencies.Add(currency);
        }

        public void AddCurrencyList(IEnumerable<Currency> currencies)
        {

            if (currencies.Count() > 0)
            {
                foreach (var currency in currencies)
                {
                    AddCurrency(new OrderCurrency 
                    {
                        CurrencyCode = currency.CurrencyCode,
                        CurrencyRate = (decimal)currency.Rate,
                        Order = this
                    });
                }

            }
        }

        public void RemoveAllCurrencies()
        {
            AllowedCurrencies.Clear();
        }

        #endregion

        public void AddPayment(OrderPayment payment)
        {
            payment.Order = this;
            Payments.Add(payment);
        }

        #endregion

    }
}
